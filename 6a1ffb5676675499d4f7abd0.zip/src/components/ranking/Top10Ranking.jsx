import { GripVertical, Trash2, Trophy } from 'lucide-react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import RankingSearchDropdown from './RankingSearchDropdown';
import { useAttractionPhotos } from '@/hooks/useAttractionPhotos';
import ATTRACTIONS from '@/lib/attractionsData';

const DEFAULT_PHOTO = 'https://images.unsplash.com/photo-1519741497674-611481863552?w=200&q=70';

const POSITION_STYLES = [
  { bg: 'linear-gradient(135deg, #FFD700 0%, #FFA500 100%)', text: 'white', shadow: 'rgba(255,165,0,0.35)' },
  { bg: 'linear-gradient(135deg, #C0C0C0 0%, #A0A0A0 100%)', text: 'white', shadow: 'rgba(160,160,160,0.35)' },
  { bg: 'linear-gradient(135deg, #CD7F32 0%, #A0522D 100%)', text: 'white', shadow: 'rgba(160,82,45,0.35)' },
];

const ROW_ACCENTS = [
  'rgba(255, 200, 50, 0.06)',
  'rgba(200, 200, 200, 0.06)',
  'rgba(180, 100, 40, 0.06)',
];

export default function Top10Ranking({ entries, onChange }) {
  const { photoMap } = useAttractionPhotos();
  const handleDragEnd = (result) => {
    if (!result.destination) return;
    const reordered = Array.from(entries);
    const [moved] = reordered.splice(result.source.index, 1);
    reordered.splice(result.destination.index, 0, moved);
    onChange(reordered.map((e, i) => ({ ...e, position: i + 1 })));
  };

  const handleAdd = (attraction) => {
    if (entries.length >= 10) return;
    if (entries.find(e => e.attraction_id === attraction.id)) return;
    onChange([...entries, {
      position: entries.length + 1,
      attraction_id: attraction.id,
      attraction_name: attraction.name,
      park: attraction.park,
    }]);
  };

  const handleRemove = (id) => {
    onChange(entries.filter(e => e.attraction_id !== id).map((e, i) => ({ ...e, position: i + 1 })));
  };

  return (
    <div className="space-y-4">
      {entries.length < 10 && (
        <RankingSearchDropdown onSelect={handleAdd} placeholder="Zoek een achtbaan om toe te voegen..." />
      )}

      {entries.length === 0 ? (
        <div className="text-center py-16">
          <div className="w-16 h-16 rounded-3xl mx-auto mb-4 flex items-center justify-center" style={{ background: 'linear-gradient(135deg, rgba(255,165,0,0.15) 0%, rgba(255,140,0,0.08) 100%)', border: '1px solid rgba(255,165,0,0.2)' }}>
            <Trophy className="w-8 h-8 text-primary" />
          </div>
          <p className="text-sm font-medium text-muted-foreground/50">Zoek en voeg achtbanen toe</p>
          <p className="text-xs text-muted-foreground/30 mt-1">Sleep om te rangschikken</p>
        </div>
      ) : (
        <DragDropContext onDragEnd={handleDragEnd}>
          <Droppable droppableId="top10">
            {(provided) => (
              <div ref={provided.innerRef} {...provided.droppableProps} className="space-y-2">
                {entries.map((entry, index) => {
                  const posStyle = POSITION_STYLES[index] || null;
                  const rowAccent = ROW_ACCENTS[index] || 'transparent';
                  const attraction = ATTRACTIONS.find(a => a.id === entry.attraction_id);
                  const photo = photoMap[entry.attraction_id] || attraction?.image_url || DEFAULT_PHOTO;
                  return (
                    <Draggable key={entry.attraction_id} draggableId={entry.attraction_id} index={index}>
                      {(provided, snapshot) => (
                        <div
                          ref={provided.innerRef}
                          {...provided.draggableProps}
                          className="flex items-center gap-3 rounded-2xl px-4 py-3 transition-all group"
                          style={{
                            ...provided.draggableProps.style,
                            background: snapshot.isDragging
                              ? 'rgba(255,255,255,0.98)'
                              : index < 3
                                ? `linear-gradient(135deg, ${rowAccent} 0%, rgba(255,255,255,0.75) 100%)`
                                : 'rgba(255,255,255,0.65)',
                            border: index < 3
                              ? `1px solid ${posStyle?.shadow || 'rgba(255,165,0,0.15)'}`
                              : '1px solid rgba(0,0,0,0.06)',
                            boxShadow: snapshot.isDragging
                              ? '0 12px 40px rgba(0,0,0,0.15)'
                              : index < 3
                                ? `0 2px 12px ${posStyle?.shadow || 'transparent'}`
                                : '0 1px 4px rgba(0,0,0,0.04)',
                            backdropFilter: 'blur(12px)',
                          }}
                        >
                          {/* Position badge */}
                          <div
                            className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 font-bold text-sm"
                            style={posStyle
                              ? { background: posStyle.bg, color: posStyle.text, boxShadow: `0 2px 8px ${posStyle.shadow}` }
                              : { background: 'rgba(0,0,0,0.06)', color: 'rgba(0,0,0,0.35)' }
                            }
                          >
                            {index < 3 ? ['1', '2', '3'][index] : `${index + 1}`}
                          </div>

                          {/* Drag handle */}
                          <div
                            {...provided.dragHandleProps}
                            className="text-muted-foreground/20 hover:text-muted-foreground/50 cursor-grab active:cursor-grabbing flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <GripVertical className="w-4 h-4" />
                          </div>

                          {/* Photo */}
                          <div className="w-10 h-10 rounded-xl overflow-hidden flex-shrink-0" style={{ border: '1px solid rgba(0,0,0,0.08)' }}>
                            <img
                              src={photo}
                              alt={entry.attraction_name}
                              className="w-full h-full object-cover"
                              onError={e => { e.target.src = DEFAULT_PHOTO; }}
                            />
                          </div>

                          {/* Info */}
                          <div className="flex-1 min-w-0">
                            <p className={`text-sm font-bold truncate ${index === 0 ? 'text-amber-600' : index === 1 ? 'text-slate-500' : index === 2 ? 'text-amber-800' : 'text-foreground'}`}>
                              {entry.attraction_name}
                            </p>
                            {entry.park && <p className="text-[11px] text-muted-foreground/50 truncate mt-0.5">{entry.park}</p>}
                          </div>

                          {/* Delete */}
                          <button
                            onClick={() => handleRemove(entry.attraction_id)}
                            className="w-7 h-7 rounded-xl flex items-center justify-center text-muted-foreground/20 hover:text-destructive hover:bg-destructive/10 transition-all flex-shrink-0 opacity-0 group-hover:opacity-100"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </Draggable>
                  );
                })}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </DragDropContext>
      )}
      {entries.length >= 10 && (
        <p className="text-xs text-muted-foreground/30 text-center pt-1">Top 10 is vol · verwijder een achtbaan om een andere toe te voegen</p>
      )}
    </div>
  );
}