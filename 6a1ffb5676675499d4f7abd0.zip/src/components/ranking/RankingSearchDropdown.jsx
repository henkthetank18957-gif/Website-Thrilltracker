import { useState, useRef, useEffect } from 'react';
import { Search, X } from 'lucide-react';
import ATTRACTIONS from '@/lib/attractionsData';

export default function RankingSearchDropdown({ onSelect, placeholder = "Zoek attractie..." }) {
  const [query, setQuery] = useState('');
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  const coasters = ATTRACTIONS.filter(a => a.type === 'coaster');
  const filtered = query.length > 1
    ? coasters.filter(a =>
        a.name.toLowerCase().includes(query.toLowerCase()) ||
        a.park.toLowerCase().includes(query.toLowerCase())
      ).slice(0, 8)
    : [];

  useEffect(() => {
    function handleClick(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  return (
    <div ref={ref} className="relative">
      <div className="flex items-center gap-2 glass rounded-2xl px-4 py-2.5" style={{ background: 'rgba(255,255,255,0.7)' }}>
        <Search className="w-4 h-4 text-muted-foreground/40 flex-shrink-0" />
        <input
          value={query}
          onChange={e => { setQuery(e.target.value); setOpen(true); }}
          onFocus={() => setOpen(true)}
          placeholder={placeholder}
          className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground/40 focus:outline-none"
        />
        {query && (
          <button onClick={() => { setQuery(''); setOpen(false); }}>
            <X className="w-3.5 h-3.5 text-muted-foreground/40 hover:text-muted-foreground" />
          </button>
        )}
      </div>
      {open && filtered.length > 0 && (
        <div className="absolute z-50 top-full mt-1 left-0 right-0 glass rounded-2xl overflow-hidden shadow-xl" style={{ background: 'rgba(255,255,255,0.95)' }}>
          {filtered.map(a => (
            <button
              key={a.id}
              onClick={() => {
                onSelect(a);
                setQuery('');
                setOpen(false);
              }}
              className="w-full text-left px-4 py-2.5 hover:bg-primary/8 transition-colors border-b border-border/30 last:border-0"
            >
              <p className="text-sm font-medium text-foreground">{a.name}</p>
              <p className="text-[11px] text-muted-foreground/60">{a.park} · {a.country}</p>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}