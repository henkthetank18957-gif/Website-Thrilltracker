import { motion } from 'framer-motion';
import { GripVertical, Trash2 } from 'lucide-react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import RankingSearchDropdown from './RankingSearchDropdown';

const CATEGORIES = [
  { id: 'overall', label: 'Overall', emoji: '⭐', desc: 'Beste achtbaan overall' },
  { id: 'restraints', label: 'Restraints', emoji: '🔒', desc: 'Beste beveiliging/harnas' },
  { id: 'elements', label: 'Elements', emoji: '🔄', desc: 'Beste inversions & elementen' },
  { id: 'pre_lift_launch', label: 'Pre lift/launch', emoji: '🚦', desc: 'Beste wachtrij & pre-launch' },
  { id: 'main_lift_launch', label: 'Main lift/launch', emoji: '🚀', desc: 'Beste lift hill of launch' },
  { id: 'theming', label: 'Theming', emoji: '🎨', desc: 'Beste theming & sfeer' },
  { id: 'length', label: 'Length', emoji: '📏', desc: 'Langste / meeste ride time' },
];

const CAT_COLORS = {
  overall:          { from: '#FFD700', to: '#FFA500', shadow: 'rgba(255,165,0,0.25)' },
  restraints:       { from: '#6366f1', to: '#8b5cf6', shadow: 'rgba(139,92,246,0.25)' },
  elements:         { from: '#06b6d4', to: '#0284c7', shadow: 'rgba(6,182,212,0.25)' },
  pre_lift_launch:  { from: '#10b981', to: '#059669', shadow: 'rgba(16,185,129,0.25)' },
  main_lift_launch: { from: '#f43f5e', to: '#e11d48', shadow: 'rgba(244,63,94,0.25)' },
  theming:          { from: '#f97316', to: '#ea580c', shadow: 'rgba(249,115,22,0.25)' },
  length:           { from: '#64748b', to: '#475569', shadow: 'rgba(100,116,139,0.25)' },
};

function CategoryColumn({ category, entries, onChange }) {
  const col = CAT_COLORS[category.id] || CAT_COLORS.overall;

  const handleDragEnd = (result) => {
    if (!result.destination) return;
    const reordered = Array.from(entries);
    const [moved] = reordered.splice(result.source.index, 1);
    reordered.splice(result.destination.index, 0, moved);
    onChange(reordered.map((e, i) => ({ ...e, position: i + 1 })));
  };

  const handleAdd = (attraction) => {
    if (entries.length >= 5) return;
    if (entries.find(e => e.attraction_id === attraction.id)) return;
    onChange([...entries, {
      position: entries.length + 1,
      attraction_id: attraction.id,
      attraction_name: attraction.name,
      park: attraction.park,
    }]);
  };

  const handleRemove = (id) => {
    onChange(entries.filter(e => e.attraction_id !== id).map((e, i) => ({ ...e, position: i + 1 })));
  };

  return (
    <div className="rounded-3xl overflow-hidden" style={{ background: 'rgba(255,255,255,0.78)', border: '1px solid rgba(255,255,255,0.9)', backdropFilter: 'blur(20px)', boxShadow: `0 4px 20px ${col.shadow}` }}>
      {/* Colored header strip */}
      <div className="px-4 pt-4 pb-3" style={{ background: `linear-gradient(135deg, ${col.from}18 0%, ${col.to}08 100%)`, borderBottom: `1px solid ${col.from}22` }}>
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl flex items-center justify-center text-base flex-shrink-0"
            style={{ background: `linear-gradient(135deg, ${col.from} 0%, ${col.to} 100%)`, boxShadow: `0 2px 8px ${col.shadow}` }}>
            {category.emoji}
          </div>
          <div>
            <h3 className="font-bold text-sm text-foreground leading-none">{category.label}</h3>
            <p className="text-[10px] text-muted-foreground/50 mt-0.5">{category.desc}</p>
          </div>
          <span className="ml-auto text-[10px] font-bold rounded-full px-2 py-0.5" style={{ background: `${col.from}20`, color: col.from }}>
            {entries.length}/5
          </span>
        </div>
      </div>

      <div className="p-3 space-y-2">
        {entries.length < 5 && (
          <RankingSearchDropdown onSelect={handleAdd} placeholder={`Voeg toe...`} />
        )}

        {entries.length === 0 ? (
          <p className="text-[11px] text-muted-foreground/30 text-center py-5">Nog geen achtbanen toegevoegd</p>
        ) : (
          <DragDropContext onDragEnd={handleDragEnd}>
            <Droppable droppableId={`cat-${category.id}`}>
              {(provided) => (
                <div ref={provided.innerRef} {...provided.droppableProps} className="space-y-1.5">
                  {entries.map((entry, index) => (
                    <Draggable key={entry.attraction_id} draggableId={`${category.id}-${entry.attraction_id}`} index={index}>
                      {(provided, snapshot) => (
                        <div
                          ref={provided.innerRef}
                          {...provided.draggableProps}
                          className="flex items-center gap-2 rounded-xl px-3 py-2.5 transition-all group"
                          style={{
                            ...provided.draggableProps.style,
                            background: snapshot.isDragging ? 'rgba(255,255,255,0.98)' : 'rgba(255,255,255,0.6)',
                            border: `1px solid ${snapshot.isDragging ? col.from + '40' : 'rgba(0,0,0,0.05)'}`,
                            boxShadow: snapshot.isDragging ? `0 8px 24px ${col.shadow}` : 'none',
                          }}
                        >
                          <div className="w-5 h-5 rounded-lg flex items-center justify-center text-[10px] font-bold flex-shrink-0"
                            style={{ background: `linear-gradient(135deg, ${col.from} 0%, ${col.to} 100%)`, color: 'white' }}>
                            {index + 1}
                          </div>
                          <div {...provided.dragHandleProps} className="text-muted-foreground/20 hover:text-muted-foreground/50 cursor-grab flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                            <GripVertical className="w-3 h-3" />
                          </div>
                          <p className="flex-1 text-xs font-semibold text-foreground truncate">{entry.attraction_name}</p>
                          <button onClick={() => handleRemove(entry.attraction_id)} className="text-muted-foreground/20 hover:text-destructive transition-colors flex-shrink-0 opacity-0 group-hover:opacity-100">
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      )}
                    </Draggable>
                  ))}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </DragDropContext>
        )}
      </div>
    </div>
  );
}

export default function CategoryRanking({ rankingsByCategory, onChange }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
      {CATEGORIES.map(cat => (
        <CategoryColumn
          key={cat.id}
          category={cat}
          entries={rankingsByCategory[cat.id] || []}
          onChange={(entries) => onChange(cat.id, entries)}
        />
      ))}
    </div>
  );
}