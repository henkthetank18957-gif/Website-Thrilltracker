import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ChevronRight, ChevronLeft, LayoutDashboard, Ticket, Map, Heart, Trophy, MapPin, ClipboardList, UserCircle, Plus, Check, BookOpen, Camera, Medal } from 'lucide-react';

const TUTORIAL_KEY = 'thrilltracker_tutorial_done';

const STEPS = [
  {
    icon: '🎢',
    title: 'Welkom bij ThrillTracker!',
    description: 'Jouw persoonlijke app om attracties te tracken, ranken en ontdekken. We leggen je even in een paar stappen uit hoe alles werkt.',
    color: 'from-primary/20 to-orange-300/10',
  },
  {
    icon: <LayoutDashboard className="w-8 h-8 text-primary" />,
    title: 'Dashboard',
    description: 'Het dashboard geeft een overzicht van jouw voortgang per land en per type attractie. Klik op een land om alle attracties daar te zien en direct af te vinken.',
    color: 'from-primary/20 to-orange-300/10',
    tip: '💡 Tap op een land om de detailweergave te openen',
  },
  {
    icon: <Ticket className="w-8 h-8 text-blue-500" />,
    title: 'Attractions',
    description: 'Hier vind je alle attracties in de database. Gebruik de filters om te zoeken op land, park, type of status. Vink attracties af als "Done" of voeg ze toe aan je Wishlist.',
    color: 'from-blue-500/20 to-blue-300/10',
    tip: '💡 Gebruik de filters bovenaan om snel te zoeken',
  },
  {
    icon: <div className="flex gap-2">
      <div className="w-8 h-8 rounded-xl bg-primary flex items-center justify-center"><Check className="w-4 h-4 text-white" strokeWidth={2.5} /></div>
      <div className="w-8 h-8 rounded-xl bg-rose-500 flex items-center justify-center"><Heart className="w-4 h-4 text-white fill-white" /></div>
    </div>,
    title: 'Done & Wishlist',
    description: 'Op elke attractiekaart staan twee knoppen: ✓ om een attractie als "gedaan" te markeren, en ♥ om hem op je wishlist te zetten. Beide zijn apart te bekijken in het menu.',
    color: 'from-rose-500/20 to-pink-300/10',
    tip: '💡 Je Wishlist staat in het linker menu onder "Wishlist"',
  },
  {
    icon: <BookOpen className="w-8 h-8 text-indigo-500" />,
    title: 'Ride Log',
    description: 'Als je een attractie als "Done" markeert, verschijnt er een 📖 knop op de kaart. Daarmee kun je een persoonlijk logboek bijhouden: notities, bezoekdatum en een foto van je bezoek.',
    color: 'from-indigo-500/20 to-purple-300/10',
    tip: '💡 De 📝 badge op een kaart betekent dat er al een log is',
  },
  {
    icon: <Map className="w-8 h-8 text-green-500" />,
    title: 'Parks',
    description: 'Bekijk alle parken op een rij. Klik op een park om alle attracties van dat park te zien. Je kunt ook de kaartweergave aanzetten via de 🗺️ Map knop.',
    color: 'from-green-500/20 to-emerald-300/10',
    tip: '💡 De voortgangsring toont hoeveel attracties je al gedaan hebt',
  },
  {
    icon: <MapPin className="w-8 h-8 text-emerald-500" />,
    title: 'Kaart (Map)',
    description: 'De interactieve kaart toont alle parklocaties wereldwijd. Elke pin toont je voortgang. Klik op een pin om de attracties van dat park te bekijken en direct af te vinken.',
    color: 'from-emerald-500/20 to-teal-300/10',
    tip: '💡 Oranje pins = veel gedaan, blauw = deels gedaan, grijs = nog niet begonnen',
  },
  {
    icon: <Trophy className="w-8 h-8 text-amber-500" />,
    title: 'Ranking',
    description: 'Maak je persoonlijke Top 10 coasters aan en rank attracties in categorieën zoals "beste theming", "beste elementen" en meer. Jouw rankings worden opgeslagen in je account.',
    color: 'from-amber-500/20 to-yellow-300/10',
    tip: '💡 Sleep kaarten om de volgorde te veranderen',
  },
  {
    icon: <Plus className="w-8 h-8 text-purple-500" />,
    title: 'Attractie toevoegen',
    description: 'Mis je een attractie in de database? Via de "Submit Attraction" knop op de Attractions-pagina kun je zelf een attractie indienen. Een admin beoordeelt je inzending.',
    color: 'from-purple-500/20 to-violet-300/10',
    tip: '💡 Je kunt de status van je inzendingen volgen op de Submissions-pagina',
  },
  {
    icon: <Medal className="w-8 h-8 text-amber-400" />,
    title: 'Achievements',
    description: 'Verdien badges door attracties te doen, parken te voltooien en landen te bezoeken. Elke badge toont je voortgang zodat je precies weet hoe ver je nog bent.',
    color: 'from-amber-400/20 to-yellow-300/10',
    tip: '💡 Elke badge heeft een voortgangsbalk — zo zie je altijd hoe ver je bent',
  },
  {
    icon: <Camera className="w-8 h-8 text-sky-500" />,
    title: 'Foto\'s (Admin)',
    description: 'Ben je een admin? Dan zie je een 📷 knop op elke attractiekaart. Daarmee kun je een officiële foto uploaden of instellen voor die attractie.',
    color: 'from-sky-500/20 to-blue-300/10',
    tip: '💡 Attracties zonder foto krijgen een standaard achtergrond',
  },
  {
    icon: <UserCircle className="w-8 h-8 text-slate-500" />,
    title: 'Account',
    description: 'Bekijk je profiel en statistieken. Van hieruit kun je ook uitloggen. Al je voortgang is gekoppeld aan je account en wordt veilig opgeslagen.',
    color: 'from-slate-500/20 to-gray-300/10',
    tip: '💡 Je stats zijn zichtbaar op je profielpagina',
  },
  {
    icon: '🚀',
    title: 'Je bent klaar!',
    description: 'Je weet nu hoe ThrillTracker werkt. Tijd om je eerste attractie af te vinken! Veel plezier met tracken.',
    color: 'from-primary/20 to-orange-300/10',
  },
];

export default function TutorialOverlay() {
  const [visible, setVisible] = useState(false);
  const [step, setStep] = useState(0);

  useEffect(() => {
    const done = localStorage.getItem(TUTORIAL_KEY);
    if (!done) setVisible(true);
  }, []);

  const finish = () => {
    localStorage.setItem(TUTORIAL_KEY, '1');
    setVisible(false);
  };

  const next = () => {
    if (step < STEPS.length - 1) setStep(s => s + 1);
    else finish();
  };

  const prev = () => setStep(s => Math.max(0, s - 1));

  if (!visible) return null;

  const current = STEPS[step];
  const isLast = step === STEPS.length - 1;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[9999] flex items-center justify-center p-4"
        style={{ background: 'rgba(10,12,20,0.65)', backdropFilter: 'blur(8px)' }}
        onClick={(e) => e.target === e.currentTarget && finish()}
      >
        <motion.div
          key={step}
          initial={{ opacity: 0, y: 24, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -12, scale: 0.97 }}
          transition={{ duration: 0.3, ease: [0.4, 0, 0.2, 1] }}
          className="relative w-full max-w-md rounded-3xl overflow-hidden"
          style={{
            background: 'linear-gradient(135deg, rgba(255,255,255,0.97) 0%, rgba(248,250,255,0.97) 100%)',
            border: '1px solid rgba(255,255,255,0.9)',
            boxShadow: '0 32px 80px rgba(0,0,0,0.25), 0 2px 0 rgba(255,255,255,0.8) inset',
          }}
        >
          {/* Top gradient band */}
          <div className={`absolute top-0 left-0 right-0 h-32 bg-gradient-to-br ${current.color} opacity-60`} />

          {/* Skip button */}
          <button
            onClick={finish}
            className="absolute top-4 right-4 z-10 flex items-center gap-1.5 text-xs text-muted-foreground/60 hover:text-muted-foreground transition-colors px-2 py-1 rounded-lg hover:bg-black/5"
          >
            <X className="w-3.5 h-3.5" /> Overslaan
          </button>

          {/* Content */}
          <div className="relative p-8 pt-10">
            {/* Step indicator */}
            <div className="flex items-center gap-1.5 mb-6">
              {STEPS.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setStep(i)}
                  className={`rounded-full transition-all duration-300 ${
                    i === step
                      ? 'w-6 h-2 bg-primary'
                      : i < step
                      ? 'w-2 h-2 bg-primary/40'
                      : 'w-2 h-2 bg-slate-200'
                  }`}
                />
              ))}
            </div>

            {/* Icon */}
            <div className="mb-5 flex items-center">
              {typeof current.icon === 'string' ? (
                <span className="text-5xl">{current.icon}</span>
              ) : (
                <div className="w-14 h-14 rounded-2xl glass flex items-center justify-center">
                  {current.icon}
                </div>
              )}
            </div>

            {/* Text */}
            <h2 className="text-xl font-bold text-foreground mb-3 leading-tight">{current.title}</h2>
            <p className="text-sm text-muted-foreground leading-relaxed mb-4">{current.description}</p>

            {current.tip && (
              <div className="glass-sm rounded-2xl px-4 py-3 mb-4">
                <p className="text-xs text-muted-foreground/80">{current.tip}</p>
              </div>
            )}

            {/* Step label */}
            <p className="text-[11px] text-muted-foreground/40 mb-5">
              Stap {step + 1} van {STEPS.length}
            </p>

            {/* Buttons */}
            <div className="flex items-center gap-3">
              {step > 0 && (
                <button
                  onClick={prev}
                  className="flex items-center gap-1.5 px-4 py-2.5 rounded-2xl glass text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  <ChevronLeft className="w-4 h-4" /> Vorige
                </button>
              )}
              <button
                onClick={next}
                className="flex-1 flex items-center justify-center gap-1.5 px-5 py-2.5 rounded-2xl bg-primary text-white text-sm font-semibold hover:bg-primary/90 transition-colors shadow-md"
              >
                {isLast ? (
                  <><span>Aan de slag!</span> 🚀</>
                ) : (
                  <><span>Volgende</span> <ChevronRight className="w-4 h-4" /></>
                )}
              </button>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}