import ProgressRing from '@/components/ui/ProgressRing';
import { motion } from 'framer-motion';

const FLAG_EMOJIS = {
  'Netherlands': '🇳🇱',
  'Belgium': '🇧🇪',
  'Germany': '🇩🇪',
  'France': '🇫🇷',
  'United Kingdom': '🇬🇧',
  'United States': '🇺🇸',
  'Spain': '🇪🇸',
  'Poland': '🇵🇱',
};

export default function CountryProgress({ country, done, total, index = 0, onClick }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05, duration: 0.4 }}
      onClick={onClick}
      className="glass rounded-3xl p-4 flex items-center gap-4 hover-glass transition-all duration-300 cursor-pointer"
    >
      <div className="relative">
        <div className="absolute inset-0 rounded-full bg-primary/10 blur-md" />
        <ProgressRing value={done} max={total} size={60} strokeWidth={4} />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="text-base leading-none">{FLAG_EMOJIS[country] || '🏳️'}</span>
          <h3 className="font-semibold text-sm text-foreground truncate">{country}</h3>
        </div>
        <p className="text-[11px] text-muted-foreground/70 mt-1">{done} of {total} done</p>
        <div className="mt-2.5 h-1 bg-white/5 rounded-full overflow-hidden">
          <motion.div
            className="h-full rounded-full"
            style={{ background: 'linear-gradient(90deg, hsl(24,100%,60%), hsl(24,100%,70%))' }}
            initial={{ width: 0 }}
            animate={{ width: total > 0 ? `${(done / total) * 100}%` : '0%' }}
            transition={{ duration: 1.2, ease: [0.4, 0, 0.2, 1], delay: index * 0.08 }}
          />
        </div>
      </div>
    </motion.div>
  );
}