import { motion, AnimatePresence } from 'framer-motion';
import { Check, Circle, ArrowLeft } from 'lucide-react';
import ATTRACTIONS from '@/lib/attractionsData';
import { useAttractionPhotos } from '@/hooks/useAttractionPhotos';
import { useAuth } from '@/lib/AuthContext';
import AttractionCard from '@/components/attractions/AttractionCard';
import ProgressRing from '@/components/ui/ProgressRing';

const FLAG_EMOJIS = {
  'Netherlands': '🇳🇱', 'Belgium': '🇧🇪', 'Germany': '🇩🇪',
  'France': '🇫🇷', 'United Kingdom': '🇬🇧', 'United States': '🇺🇸',
  'Spain': '🇪🇸', 'Poland': '🇵🇱',
};

export default function CountryDetail({ country, isDone, isWishlist, toggleDone, toggleWishlist, onBack }) {
  const { photoMap } = useAttractionPhotos();
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';

  const attractions = ATTRACTIONS.filter(a => a.country === country);
  const done = attractions.filter(a => isDone(a.id));
  const todo = attractions.filter(a => !isDone(a.id));

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      className="space-y-6"
    >
      {/* Back button */}
      <button
        onClick={onBack}
        className="text-xs text-muted-foreground/60 hover:text-primary transition-colors flex items-center gap-1.5 group"
      >
        <ArrowLeft className="w-3.5 h-3.5 group-hover:-translate-x-0.5 transition-transform" />
        Back to Dashboard
      </button>

      {/* Header */}
      <div className="flex items-center gap-5">
        <div className="relative">
          <div className="absolute inset-0 rounded-full bg-primary/15 blur-md" />
          <ProgressRing value={done.length} max={attractions.length} size={72} strokeWidth={5} />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-foreground tracking-tight">
            {FLAG_EMOJIS[country] || '🏳️'} {country}
          </h2>
          <p className="text-sm text-muted-foreground/60 mt-0.5">
            {done.length} of {attractions.length} done · {todo.length} remaining
          </p>
        </div>
      </div>

      {/* Done section */}
      {done.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4 text-primary" />
            <p className="text-[11px] font-semibold text-muted-foreground/60 uppercase tracking-[0.12em]">Done ({done.length})</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            <AnimatePresence>
              {done.map(a => (
                <AttractionCard
                  key={a.id}
                  attraction={a}
                  isDone={isDone(a.id)}
                  isWishlist={isWishlist(a.id)}
                  onToggleDone={toggleDone}
                  onToggleWishlist={toggleWishlist}
                  photoUrl={photoMap[a.id]}
                  isAdmin={isAdmin}
                />
              ))}
            </AnimatePresence>
          </div>
        </div>
      )}

      {/* To do section */}
      {todo.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Circle className="w-4 h-4 text-muted-foreground/40" />
            <p className="text-[11px] font-semibold text-muted-foreground/60 uppercase tracking-[0.12em]">Still to do ({todo.length})</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            <AnimatePresence>
              {todo.map(a => (
                <AttractionCard
                  key={a.id}
                  attraction={a}
                  isDone={isDone(a.id)}
                  isWishlist={isWishlist(a.id)}
                  onToggleDone={toggleDone}
                  onToggleWishlist={toggleWishlist}
                  photoUrl={photoMap[a.id]}
                  isAdmin={isAdmin}
                />
              ))}
            </AnimatePresence>
          </div>
        </div>
      )}
    </motion.div>
  );
}