import { motion } from 'framer-motion';
import AnimatedCounter from '@/components/ui/AnimatedCounter';

export default function StatCard({ label, value, icon: Icon, accent = false, subtitle, clickable = false }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      className={`relative overflow-hidden rounded-3xl p-5 transition-all duration-300 hover:-translate-y-0.5 ${
        clickable ? 'cursor-pointer hover:ring-2 hover:ring-primary/30' : 'cursor-default'
      } ${accent ? 'glass-primary glow-primary' : 'glass'}`}
    >
      {/* Subtle top highlight */}
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />

      <div className="flex items-start justify-between">
        <div>
          <p className="text-[11px] font-semibold text-muted-foreground/80 uppercase tracking-[0.1em]">{label}</p>
          <p className={`text-3xl font-bold mt-2 tracking-tight ${accent ? 'text-primary' : 'text-foreground'}`}>
            <AnimatedCounter value={value} />
          </p>
          {subtitle && <p className="text-[11px] text-muted-foreground/70 mt-1">{subtitle}</p>}
        </div>
        {Icon && (
          <div className={`p-2.5 rounded-2xl ${accent ? 'bg-primary/20' : 'bg-white/5'}`}>
            <Icon className={`w-5 h-5 ${accent ? 'text-primary' : 'text-muted-foreground/70'}`} />
          </div>
        )}
      </div>
    </motion.div>
  );
}