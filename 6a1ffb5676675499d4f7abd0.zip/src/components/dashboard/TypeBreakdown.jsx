import { motion } from 'framer-motion';

const TYPE_CONFIG = {
  coaster: { label: 'Coasters', emoji: '🎢', gradient: 'from-primary to-orange-400' },
  flat: { label: 'Flat Rides', emoji: '🎡', gradient: 'from-chart-2 to-blue-400' },
  dark: { label: 'Dark Rides', emoji: '👻', gradient: 'from-chart-4 to-purple-400' },
  water: { label: 'Water Rides', emoji: '💧', gradient: 'from-chart-2 to-cyan-400' },
  show: { label: 'Shows', emoji: '🎭', gradient: 'from-chart-3 to-green-400' },
};

export default function TypeBreakdown({ typeCounts }) {
  return (
    <div className="rounded-3xl p-5" style={{
      background: 'linear-gradient(160deg, hsl(220 28% 16%) 0%, hsl(225 22% 12%) 100%)',
      border: '1px solid rgba(255,255,255,0.07)',
      boxShadow: '0 4px 24px rgba(0,0,0,0.15), 0 1px 0 rgba(255,255,255,0.05) inset',
    }}>
      <h3 className="font-semibold text-[11px] uppercase tracking-[0.12em] mb-4" style={{ color: 'hsl(220 15% 55%)' }}>By Type</h3>
      <div className="space-y-3.5">
        {Object.entries(typeCounts).map(([type, { done, total }], i) => {
          const config = TYPE_CONFIG[type] || { label: type, emoji: '🎪', gradient: 'from-muted-foreground to-muted-foreground' };
          const pct = total > 0 ? (done / total) * 100 : 0;
          return (
            <div key={type}>
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-medium" style={{ color: 'hsl(220 15% 70%)' }}>
                  {config.emoji} {config.label}
                </span>
                <span className="text-[11px] font-semibold" style={{ color: 'hsl(220 15% 50%)' }}>{done}/{total}</span>
              </div>
              <div className="h-1.5 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.07)' }}>
                <motion.div
                  className={`h-full rounded-full bg-gradient-to-r ${config.gradient}`}
                  initial={{ width: 0 }}
                  animate={{ width: `${pct}%` }}
                  transition={{ duration: 1.2, ease: [0.4, 0, 0.2, 1], delay: i * 0.08 }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}