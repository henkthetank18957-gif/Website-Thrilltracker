import { useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Check, Heart } from 'lucide-react';
import ATTRACTIONS from '@/lib/attractionsData';

// Fix Leaflet default icon in Vite
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

const PARK_COORDS = {
  // Netherlands
  'Efteling': [51.6497, 5.0462],
  'Walibi Holland': [52.4383, 5.7717],
  'Toverland': [51.4167, 6.0667],
  'Duinrell': [52.1333, 4.3667],
  'Avonturenpark Hellendoorn': [52.3667, 6.4500],
  'Attractiepark Slagharen': [52.6250, 6.5583],
  // Belgium
  'Plopsaland De Panne': [51.0667, 2.5833],
  'Walibi Belgium': [50.7000, 4.6500],
  'Bobbejaanland': [51.1583, 4.9722],
  // Germany
  'Phantasialand': [50.7983, 6.8717],
  'Europa-Park': [48.2639, 7.7219],
  'Heide Park': [53.0383, 9.8694],
  'Movie Park Germany': [51.6228, 6.9581],
  // France
  'Disneyland Paris': [48.8672, 2.7833],
  'Parc Astérix': [49.1333, 2.5667],
  // United Kingdom
  'Alton Towers': [52.9897, -1.8897],
  'Thorpe Park': [51.4056, -0.5100],
  'Blackpool Pleasure Beach': [53.7900, -3.0500],
  // United States
  'Cedar Point': [41.4804, -82.6826],
  'Six Flags Magic Mountain': [34.4258, -118.5974],
  'Six Flags Great Adventure': [40.1368, -74.4408],
  'Six Flags Over Texas': [32.7564, -97.0655],
  'Six Flags Over Georgia': [33.7675, -84.5519],
  'Busch Gardens Williamsburg': [37.2310, -76.6462],
  'Busch Gardens Tampa': [27.9847, -82.4258],
  'SeaWorld Orlando': [28.4120, -81.4614],
  'Universal Islands of Adventure': [28.4714, -81.4713],
  'Universal Studios Florida': [28.4747, -81.4681],
  'Walt Disney World - Magic Kingdom': [28.4177, -81.5812],
  'Walt Disney World - Animal Kingdom': [28.3553, -81.5901],
  'Walt Disney World - Hollywood Studios': [28.3575, -81.5600],
  'Walt Disney World - EPCOT': [28.3747, -81.5499],
  // Spain
  'PortAventura World': [41.0875, 1.1564],
  // Poland
  'Energylandia': [49.9697, 19.8503],
};

const FLAG_EMOJIS = {
  'Netherlands': '🇳🇱', 'Belgium': '🇧🇪', 'Germany': '🇩🇪',
  'France': '🇫🇷', 'United Kingdom': '🇬🇧', 'United States': '🇺🇸',
  'Spain': '🇪🇸', 'Poland': '🇵🇱',
};

function createParkIcon(donePercent) {
  const color = donePercent >= 80 ? '#f97316' : donePercent >= 40 ? '#3b82f6' : '#64748b';
  return L.divIcon({
    className: '',
    html: `<div style="
      width:32px;height:32px;border-radius:50%;
      background:${color};
      border:3px solid white;
      box-shadow:0 2px 8px rgba(0,0,0,0.3);
      display:flex;align-items:center;justify-content:center;
      font-size:11px;font-weight:700;color:white;
    ">${Math.round(donePercent)}%</div>`,
    iconSize: [32, 32],
    iconAnchor: [16, 16],
  });
}

export default function ParkMap({ isDone, isWishlist, toggleDone, toggleWishlist, onParkClick, height = '400px' }) {
  const parks = Object.keys(PARK_COORDS).map(name => {
    const attractions = ATTRACTIONS.filter(a => a.park === name);
    const done = attractions.filter(a => isDone(a.id)).length;
    const country = attractions[0]?.country || '';
    return { name, attractions, done, total: attractions.length, country };
  }).filter(p => p.total > 0);

  return (
    <div style={{ height, borderRadius: '1rem', overflow: 'hidden', border: '1px solid rgba(255,255,255,0.8)' }}>
      <MapContainer
        center={[48, 10]}
        zoom={4}
        style={{ height: '100%', width: '100%' }}
        scrollWheelZoom={false}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {parks.map(park => {
          const coords = PARK_COORDS[park.name];
          if (!coords) return null;
          const pct = park.total > 0 ? (park.done / park.total) * 100 : 0;
          return (
            <Marker key={park.name} position={coords} icon={createParkIcon(pct)}>
              <Popup minWidth={240} maxWidth={280}>
                <div style={{ fontFamily: 'Inter, sans-serif', padding: '4px 0' }}>
                  <div
                    style={{ cursor: onParkClick ? 'pointer' : 'default', marginBottom: 8 }}
                    onClick={() => onParkClick && onParkClick(park.name)}
                  >
                    <div style={{ fontWeight: 700, fontSize: 14, color: '#1e293b' }}>
                      {FLAG_EMOJIS[park.country]} {park.name}
                    </div>
                    <div style={{ fontSize: 12, color: '#64748b', marginTop: 2 }}>
                      {park.done}/{park.total} done
                      {onParkClick && <span style={{ color: '#f97316', marginLeft: 8 }}>→ details</span>}
                    </div>
                  </div>

                  {/* Progress bar */}
                  <div style={{ background: '#f1f5f9', borderRadius: 4, height: 6, marginBottom: 10 }}>
                    <div style={{ background: '#f97316', borderRadius: 4, height: 6, width: `${pct}%`, transition: 'width 0.3s' }} />
                  </div>

                  {/* Attractions list */}
                  <div style={{ maxHeight: 160, overflowY: 'auto' }}>
                    {park.attractions.map(a => (
                      <div key={a.id} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '3px 0', borderBottom: '1px solid #f1f5f9' }}>
                        <button
                          onClick={() => toggleDone(a.id)}
                          style={{
                            width: 22, height: 22, borderRadius: 6, border: 'none', cursor: 'pointer', flexShrink: 0,
                            background: isDone(a.id) ? '#f97316' : '#e2e8f0',
                            display: 'flex', alignItems: 'center', justifyContent: 'center',
                          }}
                        >
                          {isDone(a.id) && <svg width="10" height="10" viewBox="0 0 10 10"><path d="M1.5 5l2.5 2.5 4.5-4.5" stroke="white" strokeWidth="1.8" fill="none" strokeLinecap="round"/></svg>}
                        </button>
                        <button
                          onClick={() => toggleWishlist(a.id)}
                          style={{
                            width: 22, height: 22, borderRadius: 6, border: 'none', cursor: 'pointer', flexShrink: 0,
                            background: isWishlist(a.id) ? '#f43f5e' : '#e2e8f0',
                            display: 'flex', alignItems: 'center', justifyContent: 'center',
                          }}
                        >
                          <svg width="10" height="10" viewBox="0 0 10 10">
                            <path d="M5 8.5C5 8.5 1 5.8 1 3.5a2 2 0 014-0 2 2 0 014 0C9 5.8 5 8.5 5 8.5z"
                              fill={isWishlist(a.id) ? 'white' : 'none'}
                              stroke={isWishlist(a.id) ? 'white' : '#94a3b8'}
                              strokeWidth="1.2"
                            />
                          </svg>
                        </button>
                        <span style={{ fontSize: 11, color: isDone(a.id) ? '#f97316' : '#475569', flex: 1, lineHeight: 1.3 }}>
                          {a.name}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </Popup>
            </Marker>
          );
        })}
      </MapContainer>
    </div>
  );
}