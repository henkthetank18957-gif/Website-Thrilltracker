import { Outlet, Link, useLocation } from 'react-router-dom';
import { MapPin, Ticket, Heart, LayoutDashboard, Menu, X, ClipboardList, UserCircle, Trophy, Map, Medal } from 'lucide-react';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import TutorialOverlay from '@/components/tutorial/TutorialOverlay';

const NAV_ITEMS = [
  { path: '/', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/attractions', label: 'Attractions', icon: Ticket },
  { path: '/parks', label: 'Parks', icon: Map },
  { path: '/wishlist', label: 'Wishlist', icon: Heart },
  { path: '/ranking', label: 'Ranking', icon: Trophy },
  { path: '/map', label: 'Map', icon: MapPin },
  { path: '/achievements', label: 'Achievements', icon: Medal },
  { path: '/submissions', label: 'Submissions', icon: ClipboardList },
  { path: '/account', label: 'Account', icon: UserCircle },
];

function NavLink({ item, active, onClick }) {
  return (
    <Link
      to={item.path}
      onClick={onClick}
      className={`relative flex items-center gap-3 px-4 py-3 rounded-2xl transition-all duration-300 group ${
        active ? '' : 'hover:bg-white/5'
      }`}
    >
      {active && (
        <motion.div
          layoutId="nav-active"
          className="absolute inset-0 rounded-2xl glass-primary"
          transition={{ type: 'spring', bounce: 0.2, duration: 0.5 }}
        />
      )}
      <item.icon className={`relative w-[18px] h-[18px] transition-colors duration-300 ${
        active ? 'text-primary' : 'text-muted-foreground group-hover:text-foreground/70'
      }`} />
      <span className={`relative font-medium text-sm transition-colors duration-300 ${
        active ? 'text-primary' : 'text-muted-foreground group-hover:text-foreground/70'
      }`}>
        {item.label}
      </span>
    </Link>
  );
}

export default function AppLayout() {
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen font-body">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:fixed lg:inset-y-0 lg:left-0 lg:flex lg:w-64 lg:flex-col z-30"
        style={{
          background: 'linear-gradient(180deg, rgba(255,255,255,0.92) 0%, rgba(248,249,255,0.96) 100%)',
          borderRight: '1px solid rgba(0,0,0,0.06)',
          backdropFilter: 'blur(40px)'
        }}
      >
        {/* Logo */}
        <div className="p-6 pb-4">
          <Link to="/" className="flex items-center gap-3 group">
            <div className="w-10 h-10 rounded-2xl glass-primary flex items-center justify-center glow-primary">
              <span className="text-white font-bold text-base tracking-tight">T</span>
            </div>
            <div>
              <h1 className="font-bold text-foreground text-sm tracking-[0.12em] uppercase">ThrillTracker</h1>
              <p className="text-[10px] text-muted-foreground tracking-widest uppercase mt-0.5 opacity-70">Ride · Track · Conquer</p>
            </div>
          </Link>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-2 space-y-0.5">
          {NAV_ITEMS.map(item => (
            <NavLink key={item.path} item={item} active={location.pathname === item.path} />
          ))}
        </nav>

        {/* Bottom decoration */}
        <div className="p-6 pt-4">
          <div className="rounded-2xl p-3 text-center" style={{
            background: 'linear-gradient(135deg, hsl(220 30% 15%) 0%, hsl(230 25% 10%) 100%)',
            border: '1px solid rgba(255,255,255,0.07)',
          }}>
            <p className="text-[10px] tracking-wide" style={{ color: 'hsl(220 15% 55%)' }}>All data stored locally</p>
          </div>
        </div>
      </aside>

      {/* Mobile Header */}
      <header className="lg:hidden fixed top-0 left-0 right-0 h-14 z-40 flex items-center justify-between px-4"
        style={{
          background: 'rgba(255,255,255,0.85)',
          backdropFilter: 'blur(30px) saturate(180%)',
          borderBottom: '1px solid rgba(0,0,0,0.06)',
        }}
      >
        <Link to="/" className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl glass-primary flex items-center justify-center">
            <span className="text-white font-bold text-sm">T</span>
          </div>
          <span className="font-bold text-foreground text-sm tracking-widest uppercase">ThrillTracker</span>
        </Link>
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="glass w-8 h-8 rounded-xl flex items-center justify-center"
        >
          {mobileOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
        </button>
      </header>

      {/* Mobile Nav Overlay */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2, ease: 'easeOut' }}
            className="lg:hidden fixed inset-x-0 top-14 z-30 p-3 space-y-0.5"
            style={{
              background: 'rgba(255,255,255,0.95)',
              backdropFilter: 'blur(40px)',
              borderBottom: '1px solid rgba(0,0,0,0.06)',
            }}
          >
            {NAV_ITEMS.map(item => (
              <NavLink
                key={item.path}
                item={item}
                active={location.pathname === item.path}
                onClick={() => setMobileOpen(false)}
              />
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      <TutorialOverlay />

      {/* Main Content */}
      <main className="lg:pl-64 pt-14 lg:pt-0 min-h-screen">
        <div className="p-4 md:p-6 lg:p-8 max-w-7xl mx-auto">
          <Outlet />
        </div>
      </main>
    </div>
  );
}