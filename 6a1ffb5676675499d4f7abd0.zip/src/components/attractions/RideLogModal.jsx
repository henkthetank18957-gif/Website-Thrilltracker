const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Upload, Calendar, MessageSquare, Loader2, Trash2 } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

export default function RideLogModal({ attraction, onClose }) {
  const qc = useQueryClient();

  const { data: logs = [], isLoading } = useQuery({
    queryKey: ['ridelog', attraction.id],
    queryFn: () => db.entities.RideLog.filter({ attraction_id: attraction.id }),
  });

  const existing = logs[0];

  const [comment, setComment] = useState(existing?.comment || '');
  const [visitDate, setVisitDate] = useState(existing?.visit_date || '');
  const [photoUrl, setPhotoUrl] = useState(existing?.photo_url || '');
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);

  // Update state when data loads
  useState(() => {
    if (existing) {
      setComment(existing.comment || '');
      setVisitDate(existing.visit_date || '');
      setPhotoUrl(existing.photo_url || '');
    }
  }, [existing]);

  const handlePhotoUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    const { file_url } = await db.integrations.Core.UploadFile({ file });
    setPhotoUrl(file_url);
    setUploading(false);
  };

  const handleSave = async () => {
    setSaving(true);
    const data = {
      attraction_id: attraction.id,
      attraction_name: attraction.name,
      comment,
      visit_date: visitDate,
      photo_url: photoUrl,
    };
    if (existing) {
      await db.entities.RideLog.update(existing.id, data);
    } else {
      await db.entities.RideLog.create(data);
    }
    qc.invalidateQueries({ queryKey: ['ridelog', attraction.id] });
    qc.invalidateQueries({ queryKey: ['ridelogs'] });
    setSaving(false);
    onClose();
  };

  const handleDelete = async () => {
    if (!existing) return;
    await db.entities.RideLog.delete(existing.id);
    qc.invalidateQueries({ queryKey: ['ridelog', attraction.id] });
    qc.invalidateQueries({ queryKey: ['ridelogs'] });
    onClose();
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4"
        style={{ background: 'rgba(0,0,0,0.4)', backdropFilter: 'blur(8px)' }}
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, y: 32 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 32 }}
          transition={{ type: 'spring', bounce: 0.2, duration: 0.4 }}
          className="glass-strong rounded-3xl w-full max-w-md overflow-hidden"
          onClick={e => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between px-5 py-4 border-b border-white/30">
            <div>
              <h2 className="font-bold text-sm text-foreground">Mijn bezoek</h2>
              <p className="text-[11px] text-muted-foreground/60 mt-0.5 truncate max-w-[240px]">{attraction.name}</p>
            </div>
            <button onClick={onClose} className="glass w-8 h-8 rounded-xl flex items-center justify-center text-muted-foreground hover:text-foreground">
              <X className="w-4 h-4" />
            </button>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-6 h-6 animate-spin text-primary" />
            </div>
          ) : (
            <div className="p-5 space-y-4">
              {/* Photo */}
              <div>
                <label className="text-xs font-semibold text-muted-foreground/70 mb-2 flex items-center gap-1.5">
                  <Upload className="w-3.5 h-3.5" /> Foto
                </label>
                {photoUrl ? (
                  <div className="relative rounded-2xl overflow-hidden h-36">
                    <img src={photoUrl} alt="Visit" className="w-full h-full object-cover" />
                    <button
                      onClick={() => setPhotoUrl('')}
                      className="absolute top-2 right-2 bg-black/50 text-white rounded-xl w-7 h-7 flex items-center justify-center hover:bg-black/70"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : (
                  <label className="flex flex-col items-center justify-center h-28 rounded-2xl border-2 border-dashed border-border/50 cursor-pointer hover:border-primary/40 hover:bg-primary/5 transition-all">
                    {uploading ? (
                      <Loader2 className="w-5 h-5 animate-spin text-primary" />
                    ) : (
                      <>
                        <Upload className="w-5 h-5 text-muted-foreground/40 mb-1.5" />
                        <span className="text-xs text-muted-foreground/50">Klik om foto te uploaden</span>
                      </>
                    )}
                    <input type="file" accept="image/*" className="hidden" onChange={handlePhotoUpload} disabled={uploading} />
                  </label>
                )}
              </div>

              {/* Date */}
              <div>
                <label className="text-xs font-semibold text-muted-foreground/70 mb-2 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5" /> Datum bezoek
                </label>
                <input
                  type="date"
                  value={visitDate}
                  onChange={e => setVisitDate(e.target.value)}
                  className="w-full px-4 py-2.5 glass rounded-2xl text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/30"
                  style={{ background: 'rgba(255,255,255,0.5)' }}
                />
              </div>

              {/* Comment */}
              <div>
                <label className="text-xs font-semibold text-muted-foreground/70 mb-2 flex items-center gap-1.5">
                  <MessageSquare className="w-3.5 h-3.5" /> Opmerking
                </label>
                <textarea
                  value={comment}
                  onChange={e => setComment(e.target.value)}
                  placeholder="Hoe was de rit? Bijzonderheden?"
                  rows={3}
                  className="w-full px-4 py-3 glass rounded-2xl text-sm text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-1 focus:ring-primary/30 resize-none"
                  style={{ background: 'rgba(255,255,255,0.5)' }}
                />
              </div>

              {/* Actions */}
              <div className="flex gap-2 pt-1">
                {existing && (
                  <button
                    onClick={handleDelete}
                    className="w-10 h-10 glass rounded-2xl flex items-center justify-center text-destructive hover:bg-destructive/10 flex-shrink-0"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
                <button
                  onClick={handleSave}
                  disabled={saving}
                  className="flex-1 h-10 bg-primary text-white rounded-2xl text-sm font-semibold flex items-center justify-center gap-2 hover:bg-primary/90 disabled:opacity-60"
                >
                  {saving && <Loader2 className="w-4 h-4 animate-spin" />}
                  {existing ? 'Bijwerken' : 'Opslaan'}
                </button>
              </div>
            </div>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}