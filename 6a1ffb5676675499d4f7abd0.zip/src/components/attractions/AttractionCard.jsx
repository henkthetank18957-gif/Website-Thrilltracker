const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from 'react';
import { Check, Heart, Star, MapPin, Camera, BookOpen } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';

import RideLogModal from './RideLogModal';
import { motion } from 'framer-motion';
import AdminPhotoModal from './AdminPhotoModal';

const TYPE_PILLS = {
  coaster: { label: '🎢 Coaster', cls: 'bg-primary/15 text-primary border-primary/20' },
  flat:    { label: '🎡 Flat',    cls: 'bg-blue-500/15 text-blue-600 border-blue-500/20' },
  dark:    { label: '👻 Dark',    cls: 'bg-purple-500/15 text-purple-600 border-purple-500/20' },
  water:   { label: '💧 Water',   cls: 'bg-cyan-500/15 text-cyan-700 border-cyan-500/20' },
  show:    { label: '🎭 Show',    cls: 'bg-green-500/15 text-green-700 border-green-500/20' },
};

const DEFAULT_PHOTO = 'https://images.unsplash.com/photo-1519741497674-611481863552?w=600&q=80';

export default function AttractionCard({ attraction: a, isDone, isWishlist, onToggleDone, onToggleWishlist, photoUrl, isAdmin }) {
  const [showPhotoModal, setShowPhotoModal] = useState(false);
  const [showLogModal, setShowLogModal] = useState(false);

  const { data: logs = [] } = useQuery({
    queryKey: ['ridelog', a.id],
    queryFn: () => db.entities.RideLog.filter({ attraction_id: a.id }),
    enabled: isDone,
  });
  const hasLog = logs.length > 0 && (logs[0].comment || logs[0].photo_url || logs[0].visit_date);
  const pill = TYPE_PILLS[a.type] || { label: a.type, cls: 'bg-slate-100 text-slate-600 border-slate-200' };
  const photo = photoUrl || a.image_url || DEFAULT_PHOTO;
  const hasRealPhoto = !!(photoUrl || a.image_url);

  return (
    <>
      <motion.div
        layout
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96 }}
        transition={{ duration: 0.3 }}
        className={`relative group rounded-3xl overflow-hidden transition-all duration-300 hover:-translate-y-0.5 hover:shadow-xl ${
          isDone ? 'ring-1 ring-primary/30' : ''
        }`}
        style={{
          background: isDone
            ? 'linear-gradient(135deg, rgba(255,255,255,0.88) 0%, rgba(255,240,225,0.70) 100%)'
            : 'linear-gradient(135deg, rgba(255,255,255,0.82) 0%, rgba(245,248,255,0.65) 100%)',
          backdropFilter: 'blur(20px)',
          border: isDone ? '1px solid rgba(255,140,0,0.20)' : '1px solid rgba(30,30,60,0.10)',
          boxShadow: isDone
            ? '0 2px 16px rgba(255,120,0,0.10), 0 1px 0 rgba(255,255,255,0.9) inset'
            : '0 2px 12px rgba(0,0,0,0.07), 0 1px 0 rgba(255,255,255,0.9) inset',
        }}
      >
        {/* Photo */}
        <div className="relative h-32 overflow-hidden">
          <img
            src={photo}
            alt={a.name}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            onError={e => { e.target.src = DEFAULT_PHOTO; }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-slate-900/10 to-transparent" />

          {isDone && (
            <div className="absolute top-2 left-2 flex items-center gap-1">
              <div className="bg-primary text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow">
                ✓ Done
              </div>
              {hasLog && (
                <div className="bg-white/90 text-primary text-[10px] font-bold px-1.5 py-0.5 rounded-full shadow" title="Logboek aanwezig">
                  📝
                </div>
              )}
            </div>
          )}

          {/* No-photo indicator for admins */}
          {isAdmin && !hasRealPhoto && (
            <div className="absolute top-2 left-2 bg-amber-500/90 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow">
              📷 Geen foto
            </div>
          )}

          <div className="absolute top-2 right-2 flex gap-1.5">
            {isDone && (
              <motion.button
                whileTap={{ scale: 0.88 }}
                onClick={(e) => { e.stopPropagation(); setShowLogModal(true); }}
                className={`w-7 h-7 rounded-xl flex items-center justify-center transition-all duration-300 shadow ${
                  hasLog ? 'bg-indigo-500 text-white' : 'bg-white/85 backdrop-blur-sm text-slate-600 hover:bg-white'
                }`}
                title="Bezoek loggen"
              >
                <BookOpen className="w-3.5 h-3.5" />
              </motion.button>
            )}
            {isAdmin && (
              <motion.button
                whileTap={{ scale: 0.88 }}
                onClick={(e) => { e.stopPropagation(); setShowPhotoModal(true); }}
                className="w-7 h-7 rounded-xl flex items-center justify-center transition-all duration-300 shadow bg-white/85 backdrop-blur-sm text-slate-600 hover:bg-white"
                title="Foto instellen (admin)"
              >
                <Camera className="w-3.5 h-3.5" />
              </motion.button>
            )}
            <motion.button
              whileTap={{ scale: 0.88 }}
              onClick={(e) => { e.stopPropagation(); onToggleDone(a.id); }}
              className={`w-7 h-7 rounded-xl flex items-center justify-center transition-all duration-300 shadow ${
                isDone
                  ? 'bg-primary text-white'
                  : 'bg-white/85 backdrop-blur-sm text-slate-600 hover:bg-white'
              }`}
            >
              <Check className="w-3.5 h-3.5" strokeWidth={2.5} />
            </motion.button>
            <motion.button
              whileTap={{ scale: 0.88 }}
              onClick={(e) => { e.stopPropagation(); onToggleWishlist(a.id); }}
              className={`w-7 h-7 rounded-xl flex items-center justify-center transition-all duration-300 shadow ${
                isWishlist
                  ? 'bg-rose-500 text-white'
                  : 'bg-white/85 backdrop-blur-sm text-slate-600 hover:bg-white'
              }`}
            >
              <Heart className={`w-3.5 h-3.5 ${isWishlist ? 'fill-white' : ''}`} strokeWidth={2} />
            </motion.button>
          </div>

          <div className="absolute bottom-2 left-3 right-3">
            <div className="flex items-center gap-1">
              <MapPin className="w-2.5 h-2.5 text-white/80 flex-shrink-0" />
              <span className="text-[10px] text-white/90 font-medium truncate drop-shadow">{a.park}</span>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-3.5">
          <h3 className={`font-bold text-sm leading-snug mb-2 ${isDone ? 'text-primary' : 'text-slate-800'}`}>
            {a.name}
          </h3>

          <div className="flex items-center gap-2 flex-wrap">
            <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${pill.cls}`}>
              {pill.label}
            </span>
            {a.thrillLevel && (
              <div className="flex items-center gap-0.5">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    className={`w-2.5 h-2.5 ${
                      i < a.thrillLevel
                        ? 'text-amber-500 fill-amber-500'
                        : 'text-slate-200 fill-slate-200'
                    }`}
                  />
                ))}
              </div>
            )}
          </div>

          {a.manufacturer && (
            <p className="text-[10px] text-slate-400 mt-1.5 font-medium">
              {a.manufacturer} · {a.yearOpened}
            </p>
          )}
        </div>
      </motion.div>

      {showLogModal && (
        <RideLogModal attraction={a} onClose={() => setShowLogModal(false)} />
      )}

      {showPhotoModal && (
        <AdminPhotoModal
          attraction={a}
          currentPhoto={photo !== DEFAULT_PHOTO ? photo : null}
          onClose={() => setShowPhotoModal(false)}
        />
      )}
    </>
  );
}