const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Upload, Loader2, Camera, Link } from 'lucide-react';

import { useSetAttractionPhoto } from '@/hooks/useAttractionPhotos';
import { toast } from 'sonner';

export default function AdminPhotoModal({ attraction, currentPhoto, onClose }) {
  const [tab, setTab] = useState('upload'); // 'upload' | 'url'
  const [url, setUrl] = useState('');
  const [uploading, setUploading] = useState(false);
  const { setPhoto, isPending } = useSetAttractionPhoto();

  const handleUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    const { file_url } = await db.integrations.Core.UploadFile({ file });
    setPhoto(attraction.id, file_url);
    toast.success('Foto opgeslagen!');
    setUploading(false);
    onClose();
  };

  const handleUrl = () => {
    if (!url.trim()) return;
    setPhoto(attraction.id, url.trim());
    toast.success('Foto opgeslagen!');
    onClose();
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center p-4"
        style={{ background: 'rgba(15,20,40,0.7)', backdropFilter: 'blur(8px)' }}
        onClick={(e) => e.target === e.currentTarget && onClose()}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ type: 'spring', bounce: 0.2, duration: 0.4 }}
          className="glass-strong rounded-3xl w-full max-w-md"
        >
          <div className="flex items-center justify-between p-5 pb-4 border-b border-slate-200/60">
            <div className="flex items-center gap-2">
              <Camera className="w-4 h-4 text-primary" />
              <div>
                <h2 className="font-bold text-foreground text-sm">Foto instellen</h2>
                <p className="text-[11px] text-muted-foreground/60">{attraction.name}</p>
              </div>
            </div>
            <button onClick={onClose} className="w-7 h-7 rounded-xl glass flex items-center justify-center">
              <X className="w-3.5 h-3.5 text-muted-foreground" />
            </button>
          </div>

          <div className="p-5 space-y-4">
            {currentPhoto && (
              <div className="relative h-32 rounded-2xl overflow-hidden">
                <img src={currentPhoto} alt="" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                <span className="absolute bottom-2 left-3 text-[10px] text-white/80 font-medium">Huidige foto</span>
              </div>
            )}

            {/* Tabs */}
            <div className="flex glass rounded-2xl p-1 gap-0.5">
              <button
                onClick={() => setTab('upload')}
                className={`flex-1 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                  tab === 'upload' ? 'glass-primary text-primary' : 'text-muted-foreground/60'
                }`}
              >
                <Upload className="w-3 h-3" /> Uploaden
              </button>
              <button
                onClick={() => setTab('url')}
                className={`flex-1 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                  tab === 'url' ? 'glass-primary text-primary' : 'text-muted-foreground/60'
                }`}
              >
                <Link className="w-3 h-3" /> URL
              </button>
            </div>

            {tab === 'upload' ? (
              <label className="flex flex-col items-center gap-3 px-4 py-6 glass rounded-2xl border-2 border-dashed border-slate-300/60 cursor-pointer hover:border-primary/40 transition-colors">
                <input type="file" accept="image/*" onChange={handleUpload} className="hidden" />
                {uploading ? (
                  <Loader2 className="w-6 h-6 text-primary animate-spin" />
                ) : (
                  <Upload className="w-6 h-6 text-muted-foreground/40" />
                )}
                <span className="text-sm text-muted-foreground/60 text-center">
                  {uploading ? 'Uploaden...' : 'Klik om een foto te uploaden'}
                </span>
              </label>
            ) : (
              <div className="space-y-3">
                <input
                  value={url}
                  onChange={e => setUrl(e.target.value)}
                  placeholder="https://..."
                  className="w-full px-4 py-2.5 glass rounded-2xl text-sm text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-1 focus:ring-primary/40 border border-slate-200/60"
                />
                <button
                  onClick={handleUrl}
                  disabled={!url.trim() || isPending}
                  className="w-full py-2.5 rounded-2xl bg-primary text-white text-sm font-semibold hover:bg-primary/90 transition-all disabled:opacity-50"
                >
                  {isPending ? 'Opslaan...' : 'Foto instellen'}
                </button>
              </div>
            )}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}