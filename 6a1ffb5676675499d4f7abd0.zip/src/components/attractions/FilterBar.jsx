import { Search } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { getCountries, getParks, getTypes } from '@/lib/attractionsData';

const TYPE_LABELS = {
  coaster: '🎢 Coasters',
  flat: '🎡 Flat Rides',
  dark: '👻 Dark Rides',
  water: '💧 Water Rides',
  show: '🎭 Shows',
};

export default function FilterBar({ filters, onFilterChange, showModeToggle = true }) {
  const countries = getCountries();
  const parks = getParks();
  const types = getTypes();

  const filteredParks = filters.country && filters.country !== 'all'
    ? parks.filter(p => p.country === filters.country)
    : parks;

  return (
    <div className="space-y-3">
      {/* Search */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/50" />
        <input
          placeholder="Search attractions..."
          value={filters.search || ''}
          onChange={(e) => onFilterChange({ ...filters, search: e.target.value })}
          className="w-full pl-11 pr-4 py-3 glass rounded-2xl text-sm text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-1 focus:ring-primary/30 transition-all"
          style={{ background: 'rgba(255,255,255,0.6)' }}
        />
      </div>

      {/* Pill filters */}
      <div className="flex flex-wrap gap-2">
        {showModeToggle && (
          <div className="flex glass rounded-2xl p-1 gap-0.5">
            <button
              onClick={() => onFilterChange({ ...filters, mode: 'all' })}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-xl transition-all duration-300 ${
                filters.mode !== 'coasters'
                  ? 'glass-primary text-primary'
                  : 'text-muted-foreground/60 hover:text-muted-foreground'
              }`}
            >
              All Rides
            </button>
            <button
              onClick={() => onFilterChange({ ...filters, mode: 'coasters' })}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-xl transition-all duration-300 ${
                filters.mode === 'coasters'
                  ? 'glass-primary text-primary'
                  : 'text-muted-foreground/60 hover:text-muted-foreground'
              }`}
            >
              🎢 Coasters
            </button>
          </div>
        )}

        <Select value={filters.country || 'all'} onValueChange={(v) => onFilterChange({ ...filters, country: v, park: 'all' })}>
          <SelectTrigger className="h-9 px-3.5 rounded-2xl text-xs glass border-0 text-muted-foreground/80 w-auto min-w-[130px]" style={{ background: 'rgba(255,255,255,0.5)' }}>
            <SelectValue placeholder="Country" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Countries</SelectItem>
            {countries.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>

        <Select value={filters.park || 'all'} onValueChange={(v) => onFilterChange({ ...filters, park: v })}>
          <SelectTrigger className="h-9 px-3.5 rounded-2xl text-xs glass border-0 text-muted-foreground/80 w-auto min-w-[150px]" style={{ background: 'rgba(255,255,255,0.5)' }}>
            <SelectValue placeholder="Park" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Parks</SelectItem>
            {filteredParks.map(p => <SelectItem key={p.name} value={p.name}>{p.name}</SelectItem>)}
          </SelectContent>
        </Select>

        {filters.mode !== 'coasters' && (
          <Select value={filters.type || 'all'} onValueChange={(v) => onFilterChange({ ...filters, type: v })}>
            <SelectTrigger className="h-9 px-3.5 rounded-2xl text-xs glass border-0 text-muted-foreground/80 w-auto min-w-[120px]" style={{ background: 'rgba(255,255,255,0.5)' }}>
              <SelectValue placeholder="Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              {types.map(t => <SelectItem key={t} value={t}>{TYPE_LABELS[t] || t}</SelectItem>)}
            </SelectContent>
          </Select>
        )}

        <Select value={filters.status || 'all'} onValueChange={(v) => onFilterChange({ ...filters, status: v })}>
          <SelectTrigger className="h-9 px-3.5 rounded-2xl text-xs glass border-0 text-muted-foreground/80 w-auto min-w-[110px]" style={{ background: 'rgba(255,255,255,0.5)' }}>
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="done">Done ✓</SelectItem>
            <SelectItem value="not_done">Not Done</SelectItem>
            <SelectItem value="wishlist">Wishlist ♥</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}