const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Plus, Upload, Loader2 } from 'lucide-react';

import { toast } from 'sonner';

const TYPES = [
  { value: 'coaster', label: '🎢 Coaster' },
  { value: 'flat', label: '🎡 Flat Ride' },
  { value: 'dark', label: '👻 Dark Ride' },
  { value: 'water', label: '💧 Water Ride' },
  { value: 'show', label: '🎭 Show' },
];

const COUNTRIES = [
  'Netherlands', 'Belgium', 'Germany', 'France', 'United Kingdom',
  'United States', 'Spain', 'Italy', 'Austria', 'Switzerland',
  'Sweden', 'Denmark', 'Japan', 'Australia', 'Other'
];

export default function AddAttractionModal({ isOpen, onClose }) {
  const [form, setForm] = useState({
    name: '', park: '', country: '', type: 'coaster',
    manufacturer: '', yearOpened: '', thrillLevel: 3,
    image_url: '', description: ''
  });
  const [uploading, setUploading] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const set = (key, val) => setForm(f => ({ ...f, [key]: val }));

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    const { file_url } = await db.integrations.Core.UploadFile({ file });
    set('image_url', file_url);
    setUploading(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name || !form.park || !form.country) return;
    setSubmitting(true);
    await db.entities.UserSubmission.create({
      ...form,
      yearOpened: form.yearOpened ? parseInt(form.yearOpened) : undefined,
      thrillLevel: parseInt(form.thrillLevel),
      status: 'pending'
    });
    setSubmitting(false);
    toast.success('Attraction submitted! An admin will review it shortly.');
    onClose();
    setForm({ name: '', park: '', country: '', type: 'coaster', manufacturer: '', yearOpened: '', thrillLevel: 3, image_url: '', description: '' });
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4"
          style={{ background: 'rgba(15,20,40,0.6)', backdropFilter: 'blur(8px)' }}
          onClick={(e) => e.target === e.currentTarget && onClose()}
        >
          <motion.div
            initial={{ opacity: 0, y: 40, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 40, scale: 0.97 }}
            transition={{ type: 'spring', bounce: 0.2, duration: 0.4 }}
            className="glass-strong rounded-3xl w-full max-w-lg max-h-[90vh] overflow-y-auto"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-6 pb-4 border-b border-slate-200/60">
              <div>
                <h2 className="font-bold text-foreground text-lg">Submit Attraction</h2>
                <p className="text-xs text-muted-foreground/70 mt-0.5">Will be reviewed by an admin</p>
              </div>
              <button onClick={onClose} className="w-8 h-8 rounded-xl glass flex items-center justify-center hover:bg-slate-100/80 transition-colors">
                <X className="w-4 h-4 text-muted-foreground" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {/* Name */}
              <div>
                <label className="text-xs font-semibold text-foreground/70 uppercase tracking-wide mb-1.5 block">Attraction Name *</label>
                <input
                  required
                  value={form.name}
                  onChange={e => set('name', e.target.value)}
                  placeholder="e.g. Taron"
                  className="w-full px-4 py-2.5 glass rounded-2xl text-sm text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-1 focus:ring-primary/40 border border-slate-200/60"
                />
              </div>

              {/* Park + Country */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-foreground/70 uppercase tracking-wide mb-1.5 block">Park *</label>
                  <input
                    required
                    value={form.park}
                    onChange={e => set('park', e.target.value)}
                    placeholder="e.g. Phantasialand"
                    className="w-full px-4 py-2.5 glass rounded-2xl text-sm text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-1 focus:ring-primary/40 border border-slate-200/60"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-foreground/70 uppercase tracking-wide mb-1.5 block">Country *</label>
                  <select
                    required
                    value={form.country}
                    onChange={e => set('country', e.target.value)}
                    className="w-full px-4 py-2.5 glass rounded-2xl text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/40 border border-slate-200/60 bg-white/60"
                  >
                    <option value="">Select...</option>
                    {COUNTRIES.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
              </div>

              {/* Type */}
              <div>
                <label className="text-xs font-semibold text-foreground/70 uppercase tracking-wide mb-1.5 block">Type *</label>
                <div className="flex flex-wrap gap-2">
                  {TYPES.map(t => (
                    <button
                      key={t.value}
                      type="button"
                      onClick={() => set('type', t.value)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all border ${
                        form.type === t.value
                          ? 'glass-primary text-primary border-primary/30'
                          : 'glass border-slate-200/60 text-muted-foreground hover:text-foreground'
                      }`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Manufacturer + Year */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-foreground/70 uppercase tracking-wide mb-1.5 block">Manufacturer</label>
                  <input
                    value={form.manufacturer}
                    onChange={e => set('manufacturer', e.target.value)}
                    placeholder="e.g. Intamin"
                    className="w-full px-4 py-2.5 glass rounded-2xl text-sm text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-1 focus:ring-primary/40 border border-slate-200/60"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-foreground/70 uppercase tracking-wide mb-1.5 block">Year Opened</label>
                  <input
                    type="number"
                    min="1900"
                    max="2030"
                    value={form.yearOpened}
                    onChange={e => set('yearOpened', e.target.value)}
                    placeholder="e.g. 2016"
                    className="w-full px-4 py-2.5 glass rounded-2xl text-sm text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-1 focus:ring-primary/40 border border-slate-200/60"
                  />
                </div>
              </div>

              {/* Thrill Level */}
              <div>
                <label className="text-xs font-semibold text-foreground/70 uppercase tracking-wide mb-1.5 block">
                  Thrill Level: {form.thrillLevel}/5
                </label>
                <div className="flex gap-2">
                  {[1,2,3,4,5].map(n => (
                    <button
                      key={n}
                      type="button"
                      onClick={() => set('thrillLevel', n)}
                      className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all border ${
                        n <= form.thrillLevel
                          ? 'bg-primary/20 text-primary border-primary/30'
                          : 'glass border-slate-200/60 text-muted-foreground/50'
                      }`}
                    >
                      {n}★
                    </button>
                  ))}
                </div>
              </div>

              {/* Photo */}
              <div>
                <label className="text-xs font-semibold text-foreground/70 uppercase tracking-wide mb-1.5 block">Photo</label>
                <label className="flex items-center gap-3 px-4 py-3 glass rounded-2xl border border-dashed border-slate-300/60 cursor-pointer hover:border-primary/40 transition-colors">
                  <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
                  {uploading ? (
                    <Loader2 className="w-4 h-4 text-primary animate-spin" />
                  ) : (
                    <Upload className="w-4 h-4 text-muted-foreground/60" />
                  )}
                  <span className="text-sm text-muted-foreground/60">
                    {form.image_url ? '✓ Photo uploaded' : 'Upload a photo'}
                  </span>
                  {form.image_url && (
                    <img src={form.image_url} alt="" className="w-8 h-8 rounded-lg object-cover ml-auto" />
                  )}
                </label>
              </div>

              {/* Description */}
              <div>
                <label className="text-xs font-semibold text-foreground/70 uppercase tracking-wide mb-1.5 block">Description</label>
                <textarea
                  value={form.description}
                  onChange={e => set('description', e.target.value)}
                  placeholder="Short description of the attraction..."
                  rows={2}
                  className="w-full px-4 py-2.5 glass rounded-2xl text-sm text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-1 focus:ring-primary/40 border border-slate-200/60 resize-none"
                />
              </div>

              {/* Submit */}
              <button
                type="submit"
                disabled={submitting}
                className="w-full py-3 rounded-2xl bg-primary text-white font-semibold text-sm flex items-center justify-center gap-2 hover:bg-primary/90 transition-all shadow-lg shadow-primary/25 disabled:opacity-60"
              >
                {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                Submit for Review
              </button>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}