import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';

import AppLayout from '@/components/layout/AppLayout';
import Dashboard from '@/pages/Dashboard';
import Attractions from '@/pages/Attractions';
import Parks from '@/pages/Parks';
import Wishlist from '@/pages/Wishlist';
import AdminReview from '@/pages/AdminReview';
import Account from '@/pages/Account';
import DoneAttractions from '@/pages/DoneAttractions';
import Ranking from '@/pages/Ranking';
import MapPage from '@/pages/MapPage';
import Achievements from '@/pages/Achievements';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-primary flex items-center justify-center">
            <span className="text-primary-foreground font-display font-bold text-xl">T</span>
          </div>
          <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin"></div>
        </div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      navigateToLogin();
      return null;
    }
  }

  return (
    <Routes>
      <Route element={<AppLayout />}>
        <Route path="/" element={<Dashboard />} />
        <Route path="/attractions" element={<Attractions />} />
        <Route path="/parks" element={<Parks />} />
        <Route path="/wishlist" element={<Wishlist />} />
        <Route path="/submissions" element={<AdminReview />} />
        <Route path="/account" element={<Account />} />
        <Route path="/done" element={<DoneAttractions />} />
        <Route path="/ranking" element={<Ranking />} />
        <Route path="/map" element={<MapPage />} />
        <Route path="/achievements" element={<Achievements />} />
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};

function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App