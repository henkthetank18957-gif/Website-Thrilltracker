const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from 'react';
import { motion } from 'framer-motion';
import { User, Mail, Shield, LogOut, Save, Loader2, BookOpen } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';

import { toast } from 'sonner';
import useUserProgress from '@/lib/useUserProgress';

export default function Account() {
  const { user } = useAuth();
  const { doneCount, wishlistCount } = useUserProgress();
  const [loggingOut, setLoggingOut] = useState(false);

  const handleLogout = async () => {
    setLoggingOut(true);
    db.auth.logout('/');
  };

  return (
    <div className="max-w-xl mx-auto space-y-6">
      <motion.div initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-2xl md:text-3xl font-bold text-foreground tracking-tight">Account</h1>
        <p className="text-sm text-muted-foreground/70 mt-1">Jouw profiel en instellingen</p>
      </motion.div>

      {/* Profile Card */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="glass rounded-3xl p-6 space-y-5"
      >
        {/* Avatar */}
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl glass-primary flex items-center justify-center text-2xl font-bold text-primary">
            {user?.full_name?.[0]?.toUpperCase() || user?.email?.[0]?.toUpperCase() || '?'}
          </div>
          <div>
            <h2 className="font-bold text-foreground text-lg">{user?.full_name || 'Gebruiker'}</h2>
            <p className="text-sm text-muted-foreground/70">{user?.email}</p>
          </div>
        </div>

        <div className="h-px bg-border/50" />

        {/* Info rows */}
        <div className="space-y-3">
          <div className="flex items-center gap-3 px-4 py-3 glass-sm rounded-2xl">
            <Mail className="w-4 h-4 text-muted-foreground/60 flex-shrink-0" />
            <div>
              <p className="text-[11px] text-muted-foreground/50 uppercase tracking-wide font-semibold">E-mailadres</p>
              <p className="text-sm text-foreground font-medium">{user?.email || '—'}</p>
            </div>
          </div>

          <div className="flex items-center gap-3 px-4 py-3 glass-sm rounded-2xl">
            <Shield className="w-4 h-4 text-muted-foreground/60 flex-shrink-0" />
            <div>
              <p className="text-[11px] text-muted-foreground/50 uppercase tracking-wide font-semibold">Rol</p>
              <p className="text-sm text-foreground font-medium capitalize">{user?.role || 'user'}</p>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Stats Card */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="glass rounded-3xl p-6"
      >
        <h3 className="font-semibold text-sm text-foreground/80 mb-4">Jouw statistieken</h3>
        <div className="grid grid-cols-2 gap-3">
          <div className="glass-primary rounded-2xl px-4 py-3 text-center">
            <p className="text-2xl font-bold text-primary">{doneCount}</p>
            <p className="text-[11px] text-muted-foreground/60 mt-0.5">Afgestreept</p>
          </div>
          <div className="glass-accent rounded-2xl px-4 py-3 text-center">
            <p className="text-2xl font-bold text-accent">{wishlistCount}</p>
            <p className="text-[11px] text-muted-foreground/60 mt-0.5">Verlanglijst</p>
          </div>
        </div>
      </motion.div>

      {/* Actions */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="space-y-3"
      >
        <button
          onClick={() => {
            localStorage.removeItem('thrilltracker_tutorial_done');
            window.location.reload();
          }}
          className="w-full py-3 rounded-2xl flex items-center justify-center gap-2 text-sm font-semibold text-primary border border-primary/20 hover:bg-primary/5 transition-colors glass"
        >
          <BookOpen className="w-4 h-4" />
          Uitleg opnieuw bekijken
        </button>

        <button
          onClick={handleLogout}
          disabled={loggingOut}
          className="w-full py-3 rounded-2xl flex items-center justify-center gap-2 text-sm font-semibold text-red-500 border border-red-200/60 hover:bg-red-50 transition-colors"
        >
          {loggingOut ? <Loader2 className="w-4 h-4 animate-spin" /> : <LogOut className="w-4 h-4" />}
          Uitloggen
        </button>
      </motion.div>
    </div>
  );
}