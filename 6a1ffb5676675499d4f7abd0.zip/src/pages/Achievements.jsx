import { useMemo } from 'react';
import { motion } from 'framer-motion';
import ATTRACTIONS from '@/lib/attractionsData';
import useUserProgress from '@/lib/useUserProgress';

// Each badge has: check(data) => boolean, progress(data) => { current, max }
const BADGES = [
  // First steps
  { id: 'first_ride', emoji: '🎟️', name: 'First Ride', desc: 'Eerste attractie afgestreept', check: (d) => d.doneCount >= 1, progress: (d) => ({ current: Math.min(d.doneCount, 1), max: 1 }) },
  { id: 'getting_started', emoji: '🚀', name: 'Getting Started', desc: '10 attracties gedaan', check: (d) => d.doneCount >= 10, progress: (d) => ({ current: Math.min(d.doneCount, 10), max: 10 }) },
  { id: 'enthusiast', emoji: '🎢', name: 'Enthusiast', desc: '25 attracties gedaan', check: (d) => d.doneCount >= 25, progress: (d) => ({ current: Math.min(d.doneCount, 25), max: 25 }) },
  { id: 'veteran', emoji: '🏅', name: 'Veteran', desc: '50 attracties gedaan', check: (d) => d.doneCount >= 50, progress: (d) => ({ current: Math.min(d.doneCount, 50), max: 50 }) },
  { id: 'legend', emoji: '👑', name: 'Legend', desc: '100 attracties gedaan', check: (d) => d.doneCount >= 100, progress: (d) => ({ current: Math.min(d.doneCount, 100), max: 100 }) },
  { id: 'completionist', emoji: '💎', name: 'Completionist', desc: 'Alle attracties gedaan', check: (d) => d.doneCount >= d.totalCount, progress: (d) => ({ current: d.doneCount, max: d.totalCount }) },

  // Coasters
  { id: 'coaster_fan', emoji: '🎠', name: 'Coaster Fan', desc: '5 achtbanen gedaan', check: (d) => d.coastersDone >= 5, progress: (d) => ({ current: Math.min(d.coastersDone, 5), max: 5 }) },
  { id: 'coaster_king', emoji: '🦁', name: 'Coaster King', desc: '20 achtbanen gedaan', check: (d) => d.coastersDone >= 20, progress: (d) => ({ current: Math.min(d.coastersDone, 20), max: 20 }) },
  { id: 'coaster_god', emoji: '⚡', name: 'Coaster God', desc: '50 achtbanen gedaan', check: (d) => d.coastersDone >= 50, progress: (d) => ({ current: Math.min(d.coastersDone, 50), max: 50 }) },

  // Thrill levels
  { id: 'thrill_seeker', emoji: '🔥', name: 'Thrill Seeker', desc: '5 attracties met thrillniveau 5', check: (d) => d.maxThrillDone >= 5, progress: (d) => ({ current: Math.min(d.maxThrillDone, 5), max: 5 }) },
  { id: 'adrenaline', emoji: '💥', name: 'Adrenaline Junkie', desc: '15 attracties met thrillniveau 5', check: (d) => d.maxThrillDone >= 15, progress: (d) => ({ current: Math.min(d.maxThrillDone, 15), max: 15 }) },
  { id: 'adrenaline_master', emoji: '🌋', name: 'Adrenaline Master', desc: '30 attracties met thrillniveau 5', check: (d) => d.maxThrillDone >= 30, progress: (d) => ({ current: Math.min(d.maxThrillDone, 30), max: 30 }) },

  // Types
  { id: 'dark_rider', emoji: '👻', name: 'Dark Rider', desc: '5 darkrides gedaan', check: (d) => d.typesDone.dark >= 5, progress: (d) => ({ current: Math.min(d.typesDone.dark, 5), max: 5 }) },
  { id: 'dark_master', emoji: '🦇', name: 'Dark Master', desc: '15 darkrides gedaan', check: (d) => d.typesDone.dark >= 15, progress: (d) => ({ current: Math.min(d.typesDone.dark, 15), max: 15 }) },
  { id: 'water_rat', emoji: '💧', name: 'Water Rat', desc: '5 waterbanen gedaan', check: (d) => d.typesDone.water >= 5, progress: (d) => ({ current: Math.min(d.typesDone.water, 5), max: 5 }) },
  { id: 'water_master', emoji: '🌊', name: 'Wave Rider', desc: '15 waterbanen gedaan', check: (d) => d.typesDone.water >= 15, progress: (d) => ({ current: Math.min(d.typesDone.water, 15), max: 15 }) },
  { id: 'flat_explorer', emoji: '🎡', name: 'Flat Explorer', desc: '5 flatrides gedaan', check: (d) => d.typesDone.flat >= 5, progress: (d) => ({ current: Math.min(d.typesDone.flat, 5), max: 5 }) },
  { id: 'show_lover', emoji: '🎭', name: 'Show Lover', desc: '3 shows gedaan', check: (d) => d.typesDone.show >= 3, progress: (d) => ({ current: Math.min(d.typesDone.show, 3), max: 3 }) },

  // Parks & Countries
  { id: 'park_visitor', emoji: '🏟️', name: 'Park Visitor', desc: '1 park volledig afgestreept', check: (d) => d.parksCompleted >= 1, progress: (d) => ({ current: Math.min(d.parksCompleted, 1), max: 1 }) },
  { id: 'park_collector', emoji: '🗺️', name: 'Park Collector', desc: '3 parken volledig afgestreept', check: (d) => d.parksCompleted >= 3, progress: (d) => ({ current: Math.min(d.parksCompleted, 3), max: 3 }) },
  { id: 'park_master', emoji: '🏰', name: 'Park Master', desc: '7 parken volledig afgestreept', check: (d) => d.parksCompleted >= 7, progress: (d) => ({ current: Math.min(d.parksCompleted, 7), max: 7 }) },
  { id: 'globetrotter', emoji: '✈️', name: 'Globetrotter', desc: 'Attracties gedaan in 3 landen', check: (d) => d.countriesVisited >= 3, progress: (d) => ({ current: Math.min(d.countriesVisited, 3), max: 3 }) },
  { id: 'world_explorer', emoji: '🌍', name: 'World Explorer', desc: 'Attracties gedaan in 5 landen', check: (d) => d.countriesVisited >= 5, progress: (d) => ({ current: Math.min(d.countriesVisited, 5), max: 5 }) },
  { id: 'world_champion', emoji: '🌐', name: 'World Champion', desc: 'Attracties gedaan in alle landen', check: (d) => d.countriesVisited >= d.totalCountries, progress: (d) => ({ current: d.countriesVisited, max: d.totalCountries }) },

  // Wishlist
  { id: 'dreamer', emoji: '⭐', name: 'Dreamer', desc: '10 attracties op verlanglijst', check: (d) => d.wishlistCount >= 10, progress: (d) => ({ current: Math.min(d.wishlistCount, 10), max: 10 }) },
  { id: 'big_dreamer', emoji: '🌠', name: 'Big Dreamer', desc: '25 attracties op verlanglijst', check: (d) => d.wishlistCount >= 25, progress: (d) => ({ current: Math.min(d.wishlistCount, 25), max: 25 }) },

  // Manufacturers
  { id: 'intamin_fan', emoji: '🔧', name: 'Intamin Fan', desc: '10 Intamin attracties gedaan', check: (d) => (d.manufacturersDone.Intamin || 0) >= 10, progress: (d) => ({ current: Math.min(d.manufacturersDone.Intamin || 0, 10), max: 10 }) },
  { id: 'bm_fan', emoji: '🏗️', name: 'B&M Believer', desc: '10 B&M attracties gedaan', check: (d) => (d.manufacturersDone['B&M'] || 0) >= 10, progress: (d) => ({ current: Math.min(d.manufacturersDone['B&M'] || 0, 10), max: 10 }) },
  { id: 'rmc_fan', emoji: '🪵', name: 'RMC Rider', desc: '5 RMC attracties gedaan', check: (d) => (d.manufacturersDone.RMC || 0) >= 5, progress: (d) => ({ current: Math.min(d.manufacturersDone.RMC || 0, 5), max: 5 }) },
  { id: 'vekoma_fan', emoji: '🛠️', name: 'Vekoma Veteran', desc: '10 Vekoma attracties gedaan', check: (d) => (d.manufacturersDone.Vekoma || 0) >= 10, progress: (d) => ({ current: Math.min(d.manufacturersDone.Vekoma || 0, 10), max: 10 }) },
  { id: 'mack_fan', emoji: '⚙️', name: 'Mack Maniac', desc: '10 Mack Rides attracties gedaan', check: (d) => (d.manufacturersDone['Mack Rides'] || 0) >= 10, progress: (d) => ({ current: Math.min(d.manufacturersDone['Mack Rides'] || 0, 10), max: 10 }) },

  // Ride logs
  { id: 'logger', emoji: '📝', name: 'Logger', desc: '5 ride logs geschreven', check: (d) => d.logCount >= 5, progress: (d) => ({ current: Math.min(d.logCount, 5), max: 5 }) },
  { id: 'journalist', emoji: '📰', name: 'Journalist', desc: '20 ride logs geschreven', check: (d) => d.logCount >= 20, progress: (d) => ({ current: Math.min(d.logCount, 20), max: 20 }) },
];

function ProgressBar({ current, max, earned }) {
  const pct = max > 0 ? (current / max) * 100 : 0;
  return (
    <div className="mt-2">
      <div className="flex justify-between text-[9px] text-muted-foreground/50 mb-1">
        <span>{current}/{max}</span>
        <span>{Math.round(pct)}%</span>
      </div>
      <div className="h-1.5 bg-black/10 rounded-full overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className={`h-full rounded-full ${earned ? 'bg-primary' : 'bg-slate-400/60'}`}
        />
      </div>
    </div>
  );
}

function BadgeCard({ badge, data, earned, index }) {
  const prog = badge.progress(data);
  return (
    <motion.div
      key={badge.id}
      initial={{ opacity: 0, scale: 0.88 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: index * 0.04 }}
      className={`rounded-2xl p-4 text-center space-y-1 transition-all duration-300 ${
        earned
          ? 'glass ring-1 ring-primary/25'
          : 'glass-sm opacity-60'
      }`}
    >
      <div className={`text-3xl ${earned ? '' : 'grayscale'}`}>{badge.emoji}</div>
      <p className="font-bold text-xs text-foreground leading-tight">{badge.name}</p>
      <p className="text-[10px] text-muted-foreground/60 leading-snug">{badge.desc}</p>
      <ProgressBar current={prog.current} max={prog.max} earned={earned} />
    </motion.div>
  );
}

export default function Achievements() {
  const { isDone, doneCount, wishlistCount } = useUserProgress();

  const data = useMemo(() => {
    const doneAttractions = ATTRACTIONS.filter(a => isDone(a.id));

    const typesDone = { coaster: 0, flat: 0, dark: 0, water: 0, show: 0 };
    doneAttractions.forEach(a => { if (typesDone[a.type] !== undefined) typesDone[a.type]++; });

    const manufacturersDone = {};
    doneAttractions.forEach(a => {
      if (a.manufacturer) manufacturersDone[a.manufacturer] = (manufacturersDone[a.manufacturer] || 0) + 1;
    });

    const countriesVisited = new Set(doneAttractions.map(a => a.country)).size;
    const totalCountries = new Set(ATTRACTIONS.map(a => a.country)).size;

    const parksDone = {};
    ATTRACTIONS.forEach(a => {
      if (!parksDone[a.park]) parksDone[a.park] = { total: 0, done: 0 };
      parksDone[a.park].total++;
      if (isDone(a.id)) parksDone[a.park].done++;
    });
    const parksCompleted = Object.values(parksDone).filter(p => p.total > 0 && p.done === p.total).length;

    const maxThrillDone = doneAttractions.filter(a => a.thrillLevel === 5).length;

    return {
      doneCount,
      wishlistCount,
      logCount: 0, // placeholder — could be fetched from RideLog entity
      totalCount: ATTRACTIONS.length,
      coastersDone: typesDone.coaster,
      typesDone,
      manufacturersDone,
      countriesVisited,
      totalCountries,
      parksCompleted,
      maxThrillDone,
    };
  }, [isDone, doneCount, wishlistCount]);

  const earned = BADGES.filter(b => b.check(data));
  const locked = BADGES.filter(b => !b.check(data));

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-2xl md:text-3xl font-bold text-foreground tracking-tight">Achievements</h1>
        <p className="text-sm text-muted-foreground/70 mt-1">{earned.length} van {BADGES.length} badges verdiend</p>
      </motion.div>

      {/* Overall progress bar */}
      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="glass rounded-2xl p-4">
        <div className="flex justify-between text-xs text-muted-foreground/60 mb-2">
          <span>Totale voortgang</span>
          <span>{earned.length}/{BADGES.length}</span>
        </div>
        <div className="h-2 bg-secondary rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${(earned.length / BADGES.length) * 100}%` }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="h-full bg-gradient-to-r from-primary to-orange-400 rounded-full"
          />
        </div>
      </motion.div>

      {/* Earned */}
      {earned.length > 0 && (
        <div className="space-y-3">
          <p className="text-[11px] font-semibold text-muted-foreground/60 uppercase tracking-[0.12em]">Verdiend 🎉</p>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {earned.map((b, i) => <BadgeCard key={b.id} badge={b} data={data} earned index={i} />)}
          </div>
        </div>
      )}

      {/* Locked */}
      <div className="space-y-3">
        <p className="text-[11px] font-semibold text-muted-foreground/60 uppercase tracking-[0.12em]">Nog te verdienen 🔒</p>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
          {locked.map((b, i) => <BadgeCard key={b.id} badge={b} data={data} earned={false} index={i} />)}
        </div>
      </div>
    </div>
  );
}