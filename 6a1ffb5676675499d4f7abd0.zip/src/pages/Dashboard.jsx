import { useMemo, useState } from 'react';
import { Ticket, Globe, Trophy, Heart } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import ATTRACTIONS, { getCountries, getTypes } from '@/lib/attractionsData';
import useUserProgress from '@/lib/useUserProgress';
import StatCard from '@/components/dashboard/StatCard';

import CountryProgress from '@/components/dashboard/CountryProgress';
import TypeBreakdown from '@/components/dashboard/TypeBreakdown';
import CountryDetail from '@/components/dashboard/CountryDetail';

export default function Dashboard() {
  const { isDone, isWishlist, toggleDone, toggleWishlist, doneCount, wishlistCount } = useUserProgress();
  const [selectedCountry, setSelectedCountry] = useState(null);

  const stats = useMemo(() => {
    const total = ATTRACTIONS.length;
    const coasters = ATTRACTIONS.filter(a => a.type === 'coaster');
    const coastersDone = coasters.filter(a => isDone(a.id)).length;
    const countriesVisited = new Set(
      ATTRACTIONS.filter(a => isDone(a.id)).map(a => a.country)
    ).size;

    const countries = getCountries();
    const countryStats = countries.map(c => {
      const ca = ATTRACTIONS.filter(a => a.country === c);
      const done = ca.filter(a => isDone(a.id)).length;
      return { country: c, done, total: ca.length };
    }).sort((a, b) => b.done - a.done);

    const types = getTypes();
    const typeCounts = {};
    types.forEach(t => {
      const ta = ATTRACTIONS.filter(a => a.type === t);
      typeCounts[t] = { done: ta.filter(a => isDone(a.id)).length, total: ta.length };
    });

    return { total, coastersDone, totalCoasters: coasters.length, countriesVisited, countryStats, typeCounts };
  }, [isDone]);

  if (selectedCountry) {
    return (
      <CountryDetail
        country={selectedCountry}
        isDone={isDone}
        isWishlist={isWishlist}
        toggleDone={toggleDone}
        toggleWishlist={toggleWishlist}
        onBack={() => setSelectedCountry(null)}
      />
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
        <div className="dark-accent rounded-3xl px-6 py-5 mb-2">
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight" style={{ color: 'hsl(220 20% 94%)' }}>Dashboard</h1>
          <p className="text-sm mt-1" style={{ color: 'hsl(220 15% 60%)' }}>Your theme park adventure at a glance</p>
        </div>
      </motion.div>

      {/* Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Link to="/done">
          <StatCard label="Total Done" value={doneCount} icon={Trophy} subtitle={`of ${stats.total} attractions`} clickable />
        </Link>
        <StatCard label="Coasters" value={stats.coastersDone} icon={Ticket} accent subtitle={`of ${stats.totalCoasters} coasters`} />
        <StatCard label="Countries" value={stats.countriesVisited} icon={Globe} subtitle={`of ${stats.countryStats.length} countries`} />
        <Link to="/wishlist">
          <StatCard label="Wishlist" value={wishlistCount} icon={Heart} subtitle="saved" clickable />
        </Link>
      </div>

      {/* Country Progress + Breakdown */}
      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-3">
          <p className="text-[11px] font-semibold text-muted-foreground/60 uppercase tracking-[0.12em]">Progress by Country</p>
          <div className="grid sm:grid-cols-2 gap-3">
            {stats.countryStats.map((cs, i) => (
              <CountryProgress
                key={cs.country}
                {...cs}
                index={i}
                onClick={() => setSelectedCountry(cs.country)}
              />
            ))}
          </div>
        </div>
        <div className="space-y-3">
          <p className="text-[11px] font-semibold text-muted-foreground/60 uppercase tracking-[0.12em]">Breakdown</p>
          <TypeBreakdown typeCounts={stats.typeCounts} />
        </div>
      </div>
    </div>
  );
}