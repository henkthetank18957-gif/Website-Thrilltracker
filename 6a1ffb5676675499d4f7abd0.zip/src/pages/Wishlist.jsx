import { useMemo, useState } from 'react';
import { Heart, Search } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import ATTRACTIONS, { getCountries } from '@/lib/attractionsData';
import useUserProgress from '@/lib/useUserProgress';
import { useAttractionPhotos } from '@/hooks/useAttractionPhotos';
import { useAuth } from '@/lib/AuthContext';
import AttractionCard from '@/components/attractions/AttractionCard';

const FLAG_EMOJIS = {
  'Netherlands': '🇳🇱', 'Belgium': '🇧🇪', 'Germany': '🇩🇪',
  'France': '🇫🇷', 'United Kingdom': '🇬🇧', 'United States': '🇺🇸',
  'Spain': '🇪🇸', 'Poland': '🇵🇱',
};

export default function Wishlist() {
  const { toggleDone, toggleWishlist, isDone, isWishlist } = useUserProgress();
  const { photoMap } = useAttractionPhotos();
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';
  const [search, setSearch] = useState('');
  const [country, setCountry] = useState('all');
  const countries = getCountries();

  const wishlistItems = useMemo(() => {
    return ATTRACTIONS.filter(a => {
      if (!isWishlist(a.id)) return false;
      if (country !== 'all' && a.country !== country) return false;
      if (search && !a.name.toLowerCase().includes(search.toLowerCase()) && !a.park.toLowerCase().includes(search.toLowerCase())) return false;
      return true;
    });
  }, [isWishlist, country, search]);

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}
        className="flex items-end justify-between gap-4 flex-wrap"
      >
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-foreground tracking-tight">Wishlist</h1>
          <p className="text-sm text-muted-foreground/70 mt-1">Attractions you want to experience</p>
        </div>
        <div className="glass rounded-2xl px-4 py-2 flex items-center gap-2">
          <Heart className="w-3.5 h-3.5 text-rose-400 fill-rose-400" />
          <span className="text-foreground font-bold text-sm">{wishlistItems.length}</span>
          <span className="text-muted-foreground/60 text-xs">saved</span>
        </div>
      </motion.div>

      <div className="flex flex-wrap gap-2">
        <div className="relative flex-1 min-w-[180px]">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/40" />
          <input
            placeholder="Search wishlist..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-11 pr-4 py-3 glass rounded-2xl text-sm text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-1 focus:ring-primary/30"
            style={{ background: 'rgba(255,255,255,0.6)' }}
          />
        </div>
        <Select value={country} onValueChange={setCountry}>
          <SelectTrigger className="h-[46px] px-4 rounded-2xl text-sm glass border-0 text-muted-foreground/80 w-auto min-w-[160px]" style={{ background: 'rgba(255,255,255,0.5)' }}>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Countries</SelectItem>
            {countries.map(c => (
              <SelectItem key={c} value={c}>{FLAG_EMOJIS[c] || ''} {c}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {wishlistItems.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          <AnimatePresence>
            {wishlistItems.map(a => (
              <AttractionCard
                key={a.id}
                attraction={a}
                isDone={isDone(a.id)}
                isWishlist={isWishlist(a.id)}
                onToggleDone={toggleDone}
                onToggleWishlist={toggleWishlist}
                photoUrl={photoMap[a.id]}
                isAdmin={isAdmin}
              />
            ))}
          </AnimatePresence>
        </div>
      ) : (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-24">
          <div className="w-16 h-16 glass rounded-3xl flex items-center justify-center mx-auto mb-4">
            <Heart className="w-7 h-7 text-muted-foreground/30" />
          </div>
          <p className="text-muted-foreground/50 text-sm font-medium">Nothing saved yet</p>
          <p className="text-muted-foreground/30 text-xs mt-1">Tap ♥ on any attraction to add it here</p>
        </motion.div>
      )}
    </div>
  );
}