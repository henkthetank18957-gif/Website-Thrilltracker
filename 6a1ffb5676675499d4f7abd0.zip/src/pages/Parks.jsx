import { useMemo, useState } from 'react';
import { Search, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import ATTRACTIONS, { getParks, getCountries } from '@/lib/attractionsData';
import useUserProgress from '@/lib/useUserProgress';
import { useAttractionPhotos } from '@/hooks/useAttractionPhotos';
import { useAuth } from '@/lib/AuthContext';
import ProgressRing from '@/components/ui/ProgressRing';
import ParkMap from '@/components/map/ParkMap';
import AttractionCard from '@/components/attractions/AttractionCard';

const FLAG_EMOJIS = {
  'Netherlands': '🇳🇱', 'Belgium': '🇧🇪', 'Germany': '🇩🇪',
  'France': '🇫🇷', 'United Kingdom': '🇬🇧', 'United States': '🇺🇸',
  'Spain': '🇪🇸', 'Poland': '🇵🇱',
};

function ParkCard({ park, done, total, onClick, index }) {
  return (
    <motion.button
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.03, duration: 0.35 }}
      onClick={onClick}
      className="glass hover-glass rounded-3xl p-4 text-left transition-all duration-300 w-full group"
    >
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/12 to-transparent rounded-t-3xl" />
      <div className="flex items-center gap-4">
        <div className="relative flex-shrink-0">
          <div className="absolute inset-0 rounded-full bg-primary/8 blur-sm" />
          <ProgressRing value={done} max={total} size={52} strokeWidth={4} />
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-sm text-foreground group-hover:text-primary transition-colors duration-300 truncate">
            {park.name}
          </h3>
          <p className="text-[11px] text-muted-foreground/60 mt-0.5">
            {FLAG_EMOJIS[park.country] || ''} {park.country}
          </p>
          <p className="text-[11px] text-muted-foreground/50 mt-0.5">{done}/{total} done</p>
        </div>
        <ChevronRight className="w-4 h-4 text-muted-foreground/30 group-hover:text-primary/70 transition-colors duration-300 flex-shrink-0" />
      </div>
    </motion.button>
  );
}

export default function Parks() {
  const { isDone, isWishlist, toggleDone, toggleWishlist } = useUserProgress();
  const { photoMap } = useAttractionPhotos();
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';
  const [search, setSearch] = useState('');
  const [country, setCountry] = useState('all');
  const [selectedPark, setSelectedPark] = useState(null);

  const parks = getParks();
  const countries = getCountries();

  const parksList = useMemo(() => {
    return parks
      .filter(p => {
        if (country !== 'all' && p.country !== country) return false;
        if (search && !p.name.toLowerCase().includes(search.toLowerCase())) return false;
        return true;
      })
      .map(p => {
        const attractions = ATTRACTIONS.filter(a => a.park === p.name);
        const done = attractions.filter(a => isDone(a.id)).length;
        return { ...p, total: attractions.length, done };
      })
      .sort((a, b) => b.total - a.total);
  }, [parks, country, search, isDone]);

  const [showMap, setShowMap] = useState(false);
  const parkAttractions = selectedPark ? ATTRACTIONS.filter(a => a.park === selectedPark) : [];

  if (selectedPark) {
    const parkInfo = parks.find(p => p.name === selectedPark);
    const done = parkAttractions.filter(a => isDone(a.id)).length;
    return (
      <div className="space-y-6">
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          onClick={() => setSelectedPark(null)}
          className="text-xs text-muted-foreground/60 hover:text-primary transition-colors flex items-center gap-1.5 group"
        >
          <span className="group-hover:-translate-x-0.5 transition-transform">←</span> Back to Parks
        </motion.button>

        <motion.div initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-5">
          <div className="relative">
            <div className="absolute inset-0 rounded-full bg-primary/15 blur-md" />
            <ProgressRing value={done} max={parkAttractions.length} size={72} strokeWidth={5} />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground tracking-tight">{selectedPark}</h1>
            <p className="text-sm text-muted-foreground/60 mt-0.5">
              {FLAG_EMOJIS[parkInfo?.country] || ''} {parkInfo?.country} · {done} of {parkAttractions.length} done
            </p>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          <AnimatePresence>
            {parkAttractions.map(a => (
              <AttractionCard
                key={a.id}
                attraction={a}
                isDone={isDone(a.id)}
                isWishlist={isWishlist(a.id)}
                onToggleDone={toggleDone}
                onToggleWishlist={toggleWishlist}
                photoUrl={photoMap[a.id]}
                isAdmin={isAdmin}
              />
            ))}
          </AnimatePresence>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
        <h1 className="text-2xl md:text-3xl font-bold text-foreground tracking-tight">Parks</h1>
        <p className="text-sm text-muted-foreground/70 mt-1">Browse attractions by park</p>
      </motion.div>

      <div className="flex flex-wrap gap-2">
        <div className="relative flex-1 min-w-[180px]">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/40" />
          <input
            placeholder="Search parks..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-11 pr-4 py-3 glass rounded-2xl text-sm text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-1 focus:ring-primary/30"
            style={{ background: 'rgba(255,255,255,0.6)' }}
          />
        </div>
        <Select value={country} onValueChange={setCountry}>
          <SelectTrigger className="h-[46px] px-4 rounded-2xl text-sm glass border-0 text-muted-foreground/80 w-auto min-w-[160px]" style={{ background: 'rgba(255,255,255,0.5)' }}>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Countries</SelectItem>
            {countries.map(c => (
              <SelectItem key={c} value={c}>{FLAG_EMOJIS[c] || ''} {c}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <button
          onClick={() => setShowMap(v => !v)}
          className={`h-[46px] px-4 rounded-2xl text-sm transition-all duration-300 font-medium ${
            showMap ? 'bg-primary text-white' : 'glass text-muted-foreground/80'
          }`}
          style={showMap ? {} : { background: 'rgba(255,255,255,0.5)' }}
        >
          🗺️ Map
        </button>
      </div>

      {showMap && (
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="glass rounded-3xl overflow-hidden">
          <ParkMap
            isDone={isDone}
            isWishlist={isWishlist}
            toggleDone={toggleDone}
            toggleWishlist={toggleWishlist}
            onParkClick={(park) => { setSelectedPark(park); setShowMap(false); }}
            height="420px"
          />
        </motion.div>
      )}

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {parksList.map((p, i) => (
          <ParkCard key={p.name} park={p} done={p.done} total={p.total} index={i} onClick={() => setSelectedPark(p.name)} />
        ))}
      </div>
    </div>
  );
}