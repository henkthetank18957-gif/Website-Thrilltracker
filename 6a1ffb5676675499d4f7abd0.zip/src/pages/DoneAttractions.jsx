const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';

import ATTRACTIONS from '@/lib/attractionsData';
import useUserProgress from '@/lib/useUserProgress';
import { useAttractionPhotos } from '@/hooks/useAttractionPhotos';
import { useAuth } from '@/lib/AuthContext';
import AttractionCard from '@/components/attractions/AttractionCard';

export default function DoneAttractions() {
  const { isDone, isWishlist, toggleDone, toggleWishlist } = useUserProgress();
  const { photoMap } = useAttractionPhotos();
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';

  const { data: approvedSubmissions = [] } = useQuery({
    queryKey: ['approved-submissions'],
    queryFn: () => db.entities.UserSubmission.filter({ status: 'approved' }),
  });

  const doneList = useMemo(() => {
    const approvedAsAttractions = approvedSubmissions.map(s => ({
      id: `sub-${s.id}`,
      name: s.name,
      park: s.park,
      country: s.country,
      type: s.type,
      manufacturer: s.manufacturer,
      yearOpened: s.yearOpened,
      thrillLevel: s.thrillLevel,
      image_url: s.image_url,
    }));
    return [...ATTRACTIONS, ...approvedAsAttractions].filter(a => isDone(a.id));
  }, [approvedSubmissions, isDone]);

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-3">
        <Link to="/" className="glass w-9 h-9 rounded-2xl flex items-center justify-center hover:bg-white/80 transition-colors">
          <ChevronLeft className="w-4 h-4 text-muted-foreground" />
        </Link>
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-foreground tracking-tight">Afgestreept</h1>
          <p className="text-sm text-muted-foreground/70 mt-1">
            <span className="text-primary font-bold">{doneList.length}</span> attracties gedaan
          </p>
        </div>
      </motion.div>

      {doneList.length === 0 ? (
        <div className="text-center py-24">
          <p className="text-4xl mb-3">🎢</p>
          <p className="text-muted-foreground/50 text-sm">Nog geen attracties afgestreept</p>
          <Link to="/attractions" className="mt-4 inline-block text-primary text-sm font-semibold hover:underline">
            Ga naar attracties →
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          <AnimatePresence>
            {doneList.map(a => (
              <AttractionCard
                key={a.id}
                attraction={a}
                isDone={isDone(a.id)}
                isWishlist={isWishlist(a.id)}
                onToggleDone={toggleDone}
                onToggleWishlist={toggleWishlist}
                photoUrl={photoMap[a.id]}
                isAdmin={isAdmin}
              />
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}