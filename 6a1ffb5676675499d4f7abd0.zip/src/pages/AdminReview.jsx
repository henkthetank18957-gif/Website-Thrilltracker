const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

import { useAuth } from '@/lib/AuthContext';
import { motion, AnimatePresence } from 'framer-motion';
import { Check, X, Clock, ChevronRight, Star, MapPin, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

const STATUS_CONFIG = {
  pending: { label: 'Pending', cls: 'bg-amber-100 text-amber-700 border-amber-200' },
  approved: { label: 'Approved', cls: 'bg-emerald-100 text-emerald-700 border-emerald-200' },
  rejected: { label: 'Rejected', cls: 'bg-red-100 text-red-700 border-red-200' },
};

const TYPE_EMOJIS = { coaster: '🎢', flat: '🎡', dark: '👻', water: '💧', show: '🎭' };

function SubmissionCard({ sub, onApprove, onReject, onDelete, isAdmin }) {
  const [noteOpen, setNoteOpen] = useState(false);
  const [note, setNote] = useState('');
  const sc = STATUS_CONFIG[sub.status] || STATUS_CONFIG.pending;

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.96 }}
      className="glass rounded-3xl overflow-hidden"
    >
      {/* Image */}
      {sub.image_url && (
        <div className="h-36 overflow-hidden">
          <img src={sub.image_url} alt={sub.name} className="w-full h-full object-cover" />
        </div>
      )}
      <div className="p-4">
        <div className="flex items-start justify-between gap-2 mb-2">
          <div>
            <h3 className="font-bold text-sm text-foreground">{sub.name}</h3>
            <div className="flex items-center gap-1 mt-0.5">
              <MapPin className="w-3 h-3 text-muted-foreground/60" />
              <span className="text-[11px] text-muted-foreground/70">{sub.park} · {sub.country}</span>
            </div>
          </div>
          <span className={`text-[10px] font-bold px-2 py-1 rounded-full border ${sc.cls}`}>
            {sc.label}
          </span>
        </div>

        <div className="flex flex-wrap gap-2 mb-3">
          <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full">
            {TYPE_EMOJIS[sub.type]} {sub.type}
          </span>
          {sub.manufacturer && (
            <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full">{sub.manufacturer}</span>
          )}
          {sub.yearOpened && (
            <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full">{sub.yearOpened}</span>
          )}
          {sub.thrillLevel && (
            <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full flex items-center gap-0.5">
              {'★'.repeat(sub.thrillLevel)} Thrill
            </span>
          )}
        </div>

        {sub.description && (
          <p className="text-[11px] text-muted-foreground/70 mb-3 leading-relaxed">{sub.description}</p>
        )}

        <div className="text-[10px] text-muted-foreground/50 mb-3">
          Submitted by: {sub.created_by} · {new Date(sub.created_date).toLocaleDateString()}
        </div>

        {sub.admin_note && (
          <div className="bg-amber-50 border border-amber-200 rounded-xl px-3 py-2 text-[11px] text-amber-700 mb-3">
            Admin note: {sub.admin_note}
          </div>
        )}

        {isAdmin && sub.status === 'pending' && (
          <div className="space-y-2">
            {noteOpen ? (
              <div className="space-y-2">
                <textarea
                  value={note}
                  onChange={e => setNote(e.target.value)}
                  placeholder="Optional note to submitter..."
                  rows={2}
                  className="w-full px-3 py-2 glass rounded-xl text-xs border border-slate-200/60 focus:outline-none focus:ring-1 focus:ring-primary/30 resize-none"
                />
                <div className="flex gap-2">
                  <button
                    onClick={() => { onApprove(sub.id, note); setNoteOpen(false); }}
                    className="flex-1 py-2 rounded-xl bg-emerald-500 text-white text-xs font-bold flex items-center justify-center gap-1 hover:bg-emerald-600 transition-colors"
                  >
                    <Check className="w-3 h-3" /> Approve
                  </button>
                  <button
                    onClick={() => { onReject(sub.id, note); setNoteOpen(false); }}
                    className="flex-1 py-2 rounded-xl bg-red-500 text-white text-xs font-bold flex items-center justify-center gap-1 hover:bg-red-600 transition-colors"
                  >
                    <X className="w-3 h-3" /> Reject
                  </button>
                  <button
                    onClick={() => setNoteOpen(false)}
                    className="py-2 px-3 rounded-xl glass text-xs text-muted-foreground hover:text-foreground transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <button
                onClick={() => setNoteOpen(true)}
                className="w-full py-2 rounded-xl glass border border-slate-200/60 text-xs font-semibold text-foreground/70 flex items-center justify-center gap-1 hover:text-foreground transition-colors"
              >
                Review <ChevronRight className="w-3 h-3" />
              </button>
            )}
          </div>
        )}

        {isAdmin && (
          <button
            onClick={() => onDelete(sub.id)}
            className="mt-2 w-full py-1.5 rounded-xl text-[11px] text-red-400 hover:bg-red-50 transition-colors flex items-center justify-center gap-1"
          >
            <Trash2 className="w-3 h-3" /> Delete
          </button>
        )}
      </div>
    </motion.div>
  );
}

export default function AdminReview() {
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';
  const [filter, setFilter] = useState('pending');
  const qc = useQueryClient();

  const { data: submissions = [] } = useQuery({
    queryKey: ['submissions'],
    queryFn: () => db.entities.UserSubmission.list('-created_date', 100),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => db.entities.UserSubmission.update(id, data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['submissions'] }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => db.entities.UserSubmission.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['submissions'] }),
  });

  const handleApprove = (id, note) => {
    updateMutation.mutate({ id, data: { status: 'approved', admin_note: note } });
    toast.success('Attraction approved!');
  };

  const handleReject = (id, note) => {
    updateMutation.mutate({ id, data: { status: 'rejected', admin_note: note } });
    toast.error('Attraction rejected.');
  };

  const handleDelete = (id) => {
    deleteMutation.mutate(id);
    toast.success('Submission deleted.');
  };

  const filtered = submissions.filter(s => filter === 'all' || s.status === filter);
  const pendingCount = submissions.filter(s => s.status === 'pending').length;

  if (!isAdmin) {
    // Regular users can only see their own submissions
    const mine = submissions.filter(s => s.created_by === user?.email);
    return (
      <div className="space-y-6">
        <motion.div initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="text-2xl md:text-3xl font-bold text-foreground tracking-tight">My Submissions</h1>
          <p className="text-sm text-muted-foreground/70 mt-1">Track the status of your submitted attractions</p>
        </motion.div>

        {mine.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-muted-foreground/50 text-sm">You haven't submitted any attractions yet</p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <AnimatePresence>
              {mine.map(s => (
                <SubmissionCard key={s.id} sub={s} isAdmin={false} onApprove={() => {}} onReject={() => {}} onDelete={() => {}} />
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }} className="flex items-end justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-foreground tracking-tight">Admin Review</h1>
          <p className="text-sm text-muted-foreground/70 mt-1">Review user-submitted attractions</p>
        </div>
        {pendingCount > 0 && (
          <div className="glass-primary rounded-2xl px-4 py-2 text-sm">
            <span className="text-primary font-bold">{pendingCount}</span>
            <span className="text-muted-foreground/70 ml-1">pending review</span>
          </div>
        )}
      </motion.div>

      {/* Filter tabs */}
      <div className="flex glass rounded-2xl p-1 gap-0.5 w-fit">
        {['pending', 'approved', 'rejected', 'all'].map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold capitalize transition-all ${
              filter === f ? 'glass-primary text-primary' : 'text-muted-foreground/60 hover:text-muted-foreground'
            }`}
          >
            {f}
            {f === 'pending' && pendingCount > 0 && (
              <span className="ml-1.5 bg-primary text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full">{pendingCount}</span>
            )}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-20">
          <p className="text-muted-foreground/50 text-sm">No {filter} submissions</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <AnimatePresence>
            {filtered.map(s => (
              <SubmissionCard
                key={s.id}
                sub={s}
                isAdmin={isAdmin}
                onApprove={handleApprove}
                onReject={handleReject}
                onDelete={handleDelete}
              />
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}