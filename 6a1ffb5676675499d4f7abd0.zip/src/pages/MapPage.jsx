import { motion } from 'framer-motion';
import useUserProgress from '@/lib/useUserProgress';
import ParkMap from '@/components/map/ParkMap';
import { useNavigate } from 'react-router-dom';

export default function MapPage() {
  const { isDone, isWishlist, toggleDone, toggleWishlist } = useUserProgress();
  const navigate = useNavigate();

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
        <h1 className="text-2xl md:text-3xl font-bold text-foreground tracking-tight">Park Map</h1>
        <p className="text-sm text-muted-foreground/70 mt-1">Klik op een marker om attracties af te vinken</p>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1, duration: 0.4 }}
        className="glass rounded-3xl overflow-hidden"
      >
        <ParkMap
          isDone={isDone}
          isWishlist={isWishlist}
          toggleDone={toggleDone}
          toggleWishlist={toggleWishlist}
          onParkClick={(park) => navigate(`/parks?park=${encodeURIComponent(park)}`)}
          height="calc(100vh - 200px)"
        />
      </motion.div>
    </div>
  );
}