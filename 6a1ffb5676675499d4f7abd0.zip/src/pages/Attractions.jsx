const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';

import ATTRACTIONS from '@/lib/attractionsData';
import useUserProgress from '@/lib/useUserProgress';
import { useAttractionPhotos } from '@/hooks/useAttractionPhotos';
import { useAuth } from '@/lib/AuthContext';
import FilterBar from '@/components/attractions/FilterBar';
import AttractionCard from '@/components/attractions/AttractionCard';
import AddAttractionModal from '@/components/attractions/AddAttractionModal';

export default function Attractions() {
  const { toggleDone, toggleWishlist, isDone, isWishlist } = useUserProgress();
  const { photoMap } = useAttractionPhotos();
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';
  const [showAddModal, setShowAddModal] = useState(false);
  const [filters, setFilters] = useState({
    search: '',
    mode: 'all',
    country: 'all',
    park: 'all',
    type: 'all',
    status: 'all',
  });

  const { data: approvedSubmissions = [] } = useQuery({
    queryKey: ['approved-submissions'],
    queryFn: () => db.entities.UserSubmission.filter({ status: 'approved' }),
  });

  const filtered = useMemo(() => {
    const approvedAsAttractions = approvedSubmissions.map(s => ({
      id: `sub-${s.id}`,
      name: s.name,
      park: s.park,
      country: s.country,
      type: s.type,
      manufacturer: s.manufacturer,
      yearOpened: s.yearOpened,
      thrillLevel: s.thrillLevel,
      image_url: s.image_url,
      description: s.description,
    }));
    let list = [...ATTRACTIONS, ...approvedAsAttractions];
    if (filters.mode === 'coasters') list = list.filter(a => a.type === 'coaster');
    if (filters.country !== 'all') list = list.filter(a => a.country === filters.country);
    if (filters.park !== 'all') list = list.filter(a => a.park === filters.park);
    if (filters.type !== 'all' && filters.mode !== 'coasters') list = list.filter(a => a.type === filters.type);
    if (filters.status === 'done') list = list.filter(a => isDone(a.id));
    else if (filters.status === 'not_done') list = list.filter(a => !isDone(a.id));
    else if (filters.status === 'wishlist') list = list.filter(a => isWishlist(a.id));
    if (filters.search) {
      const q = filters.search.toLowerCase();
      list = list.filter(a =>
        a.name.toLowerCase().includes(q) ||
        a.park.toLowerCase().includes(q) ||
        a.manufacturer?.toLowerCase().includes(q)
      );
    }
    return list;
  }, [filters, isDone, isWishlist]);

  const doneCount = filtered.filter(a => isDone(a.id)).length;

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}
        className="flex items-end justify-between gap-4 flex-wrap"
      >
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-foreground tracking-tight">Attractions</h1>
          <p className="text-sm text-muted-foreground/70 mt-1">Browse and track every ride</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="glass rounded-2xl px-4 py-2 text-sm">
            <span className="text-primary font-bold">{doneCount}</span>
            <span className="text-muted-foreground/60"> / </span>
            <span className="text-foreground font-semibold">{filtered.length}</span>
            <span className="text-muted-foreground/60 text-xs ml-1">done</span>
          </div>
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-4 py-2 rounded-2xl bg-primary text-white text-sm font-semibold hover:bg-primary/90 transition-all shadow-lg shadow-primary/25"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Submit</span>
          </button>
        </div>
      </motion.div>

      <AddAttractionModal isOpen={showAddModal} onClose={() => setShowAddModal(false)} />

      <FilterBar filters={filters} onFilterChange={setFilters} />

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
        <AnimatePresence>
          {filtered.map(a => (
            <AttractionCard
              key={a.id}
              attraction={a}
              isDone={isDone(a.id)}
              isWishlist={isWishlist(a.id)}
              onToggleDone={toggleDone}
              onToggleWishlist={toggleWishlist}
              photoUrl={photoMap[a.id]}
              isAdmin={isAdmin}
            />
          ))}
        </AnimatePresence>
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-20">
          <p className="text-muted-foreground/50 text-sm">No attractions match your filters</p>
        </div>
      )}
    </div>
  );
}