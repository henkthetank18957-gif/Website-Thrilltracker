const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Trophy, Star, Save, Check } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

import Top10Ranking from '@/components/ranking/Top10Ranking';
import CategoryRanking from '@/components/ranking/CategoryRanking';

const TABS = [
  { id: 'top10', label: 'Top 10', icon: Trophy },
  { id: 'categories', label: 'Categorieën', icon: Star },
];

export default function Ranking() {
  const [activeTab, setActiveTab] = useState('top10');
  const [top10Entries, setTop10Entries] = useState([]);
  const [categoryEntries, setCategoryEntries] = useState({});
  const [saved, setSaved] = useState(false);
  const queryClient = useQueryClient();

  const { data: rankings = [], isLoading } = useQuery({
    queryKey: ['rankings'],
    queryFn: () => db.entities.Ranking.list(),
  });

  // Initialize state from DB
  useEffect(() => {
    if (!rankings.length) return;
    const top10 = rankings.find(r => r.type === 'top10');
    if (top10) setTop10Entries(top10.entries || []);

    const catMap = {};
    rankings.filter(r => r.type === 'category').forEach(r => {
      catMap[r.category] = r.entries || [];
    });
    setCategoryEntries(catMap);
  }, [rankings]);

  const saveMutation = useMutation({
    mutationFn: async () => {
      const existing = rankings;

      // Save top10
      const existingTop10 = existing.find(r => r.type === 'top10');
      if (existingTop10) {
        await db.entities.Ranking.update(existingTop10.id, { entries: top10Entries });
      } else {
        await db.entities.Ranking.create({ type: 'top10', entries: top10Entries });
      }

      // Save each category
      const categories = ['overall', 'restraints', 'elements', 'pre_lift_launch', 'main_lift_launch', 'theming', 'length'];
      for (const cat of categories) {
        const existingCat = existing.find(r => r.type === 'category' && r.category === cat);
        const entries = categoryEntries[cat] || [];
        if (existingCat) {
          await db.entities.Ranking.update(existingCat.id, { entries });
        } else {
          await db.entities.Ranking.create({ type: 'category', category: cat, entries });
        }
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['rankings'] });
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    },
  });

  const handleCategoryChange = useCallback((catId, entries) => {
    setCategoryEntries(prev => ({ ...prev, [catId]: entries }));
  }, []);

  return (
    <div className="space-y-6">
      {/* Hero header */}
      <motion.div initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
        <div className="relative rounded-3xl overflow-hidden px-6 py-6"
          style={{
            background: 'linear-gradient(135deg, hsl(220 30% 14%) 0%, hsl(230 25% 10%) 100%)',
            border: '1px solid rgba(255,255,255,0.07)',
          }}
        >
          {/* Subtle glow blobs */}
          <div className="absolute -top-8 -left-8 w-40 h-40 rounded-full opacity-20" style={{ background: 'radial-gradient(circle, hsl(24 100% 55%) 0%, transparent 70%)' }} />
          <div className="absolute -bottom-8 -right-8 w-32 h-32 rounded-full opacity-10" style={{ background: 'radial-gradient(circle, hsl(210 90% 55%) 0%, transparent 70%)' }} />

          <div className="relative flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0"
                style={{ background: 'linear-gradient(135deg, #FFD700 0%, #FFA500 100%)', boxShadow: '0 4px 16px rgba(255,165,0,0.4)' }}>
                <Trophy className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl md:text-3xl font-bold tracking-tight" style={{ color: 'hsl(220 20% 94%)' }}>Mijn Ranking</h1>
                <p className="text-sm mt-0.5" style={{ color: 'hsl(220 15% 55%)' }}>Rangschik je favoriete achtbanen</p>
              </div>
            </div>
            <button
              onClick={() => saveMutation.mutate()}
              disabled={saveMutation.isPending}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-2xl text-sm font-semibold transition-all ${
                saved ? 'bg-green-500 text-white shadow-lg shadow-green-500/30' : 'bg-primary text-white hover:bg-primary/90 shadow-lg shadow-primary/30'
              }`}
            >
              {saved ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
              {saved ? 'Opgeslagen!' : 'Opslaan'}
            </button>
          </div>
        </div>
      </motion.div>

      {/* Tabs */}
      <div className="flex gap-2 p-1 rounded-2xl w-fit" style={{ background: 'rgba(255,255,255,0.55)', border: '1px solid rgba(0,0,0,0.06)' }}>
        {TABS.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold transition-all duration-200 ${
              activeTab === tab.id
                ? 'bg-primary text-white shadow-md shadow-primary/25'
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="flex justify-center py-16">
          <div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin" />
        </div>
      ) : (
        <motion.div key={activeTab} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
          {activeTab === 'top10' && (
            <div className="rounded-3xl p-6" style={{ background: 'rgba(255,255,255,0.72)', border: '1px solid rgba(255,255,255,0.9)', backdropFilter: 'blur(24px)', boxShadow: '0 4px 24px rgba(0,0,0,0.06)' }}>
              <div className="flex items-center gap-3 mb-5">
                <div className="w-8 h-8 rounded-xl flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #FFD700 0%, #FFA500 100%)' }}>
                  <Trophy className="w-4 h-4 text-white" />
                </div>
                <h2 className="font-bold text-base text-foreground">Top 10 Achtbanen</h2>
                <div className="ml-auto flex items-center gap-1.5">
                  <div className="h-1.5 rounded-full overflow-hidden w-20" style={{ background: 'rgba(0,0,0,0.07)' }}>
                    <div className="h-full rounded-full bg-primary transition-all duration-500" style={{ width: `${(top10Entries.length / 10) * 100}%` }} />
                  </div>
                  <span className="text-xs font-semibold text-muted-foreground/60">{top10Entries.length}/10</span>
                </div>
              </div>
              <Top10Ranking entries={top10Entries} onChange={setTop10Entries} />
            </div>
          )}
          {activeTab === 'categories' && (
            <div className="space-y-3">
              <p className="text-xs text-muted-foreground/40 font-medium">Sleep om te rangschikken · max 5 per categorie</p>
              <CategoryRanking rankingsByCategory={categoryEntries} onChange={handleCategoryChange} />
            </div>
          )}
        </motion.div>
      )}
    </div>
  );
}