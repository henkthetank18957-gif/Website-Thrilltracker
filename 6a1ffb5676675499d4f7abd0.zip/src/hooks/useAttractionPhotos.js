const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

export function useAttractionPhotos() {
  const { data: photos = [] } = useQuery({
    queryKey: ['attraction-photos'],
    queryFn: () => db.entities.AttractionPhoto.list(),
    staleTime: 5 * 60 * 1000,
  });

  const photoMap = {};
  photos.forEach(p => { photoMap[p.attraction_id] = p.image_url; });

  return { photoMap, photos };
}

export function useSetAttractionPhoto() {
  const qc = useQueryClient();
  const { photos } = useAttractionPhotos();

  const createMutation = useMutation({
    mutationFn: (data) => db.entities.AttractionPhoto.create(data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['attraction-photos'] }),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => db.entities.AttractionPhoto.update(id, data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['attraction-photos'] }),
  });

  const setPhoto = (attractionId, imageUrl) => {
    const existing = photos.find(p => p.attraction_id === attractionId);
    if (existing) {
      updateMutation.mutate({ id: existing.id, data: { image_url: imageUrl } });
    } else {
      createMutation.mutate({ attraction_id: attractionId, image_url: imageUrl });
    }
  };

  return { setPhoto, isPending: createMutation.isPending || updateMutation.isPending };
}